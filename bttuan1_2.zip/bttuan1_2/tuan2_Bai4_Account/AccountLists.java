package tuan2_Bai4_Account;

public class AccountLists {
	public int soPtThat;
	Account[] dsAcc;
	/**
	 * @Contructor
	 */
	public AccountLists(int soPt) {
		// init Array
		dsAcc = new Account[soPt];
	}
	/**
	 * @Tăng kích thước mảng
	 */
	public void tangMang() {
		//step 1: tăng kích thước *2
		Account[] accTemp = new Account[dsAcc.length * 2];
		//step 2: gắn giá trị ds vào array tạm
		for(int i = 0; i<dsAcc.length; i++) {
			accTemp[i] = dsAcc[i];
		}
		//step 3: gắn mảng tạm = ds Acc
		dsAcc = accTemp;
	}

	public Account timAccount(long soTaiKhoan) {
		for(int i = 0; i<soPtThat ; i++) {
			if(soTaiKhoan == dsAcc[i].getSoTaiKhoan()) {
				return dsAcc[i];
			}
		}
		//Khi ko thấy nó trong mảng
		return null;

	}
	public boolean themAccount(Account acc) {
		if(this.timAccount(acc.getSoTaiKhoan()) != null) {//có
			return false;
		}else {
			if(soPtThat == dsAcc.length) {
				tangMang();
				
			}
			dsAcc[soPtThat] = acc;
			soPtThat++;
			return true;
		}
	}

	public int timViTriAcc(long soTaiKhoan) {
		int temp = 0;
		for(int i = 0; i< soPtThat;i++) {
			if(dsAcc[i].getSoTaiKhoan() == soTaiKhoan) {
				temp = i;
				break;
			}
		}
		return temp;
	}

	//	public boolean kiemTraTien(long soTaiKhoan) {
	//		int vitri = timViTriAcc(soTaiKhoan);
	//		if(dsAcc[i]) {
	//			return true;
	//		}else {
	//			return false;
	//		}
	//		
	//	}

	public Account[] layDanhSachTaiKhoan() {
		return dsAcc;
	}
}
