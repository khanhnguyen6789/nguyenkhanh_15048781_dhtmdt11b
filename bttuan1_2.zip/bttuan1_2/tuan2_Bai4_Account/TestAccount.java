package tuan2_Bai4_Account;

import java.text.DecimalFormat;
import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int soPhanTu = 5;
		AccountLists dsAccount = new AccountLists(soPhanTu);

		Account ac1 = new Account(1, "Hoàng Dung");//default
		Account ac2 = new Account(2, "Quách Tĩnh", 500000);
		Account ac3 = new Account(3, "Dương Quá", 1000000);
		dsAccount.themAccount(ac1);
		dsAccount.themAccount(ac2);
		dsAccount.themAccount(ac3);

		//main
		menu(dsAccount);

	}
	/**
	 * @Thêm mới
	 * @param dsAccount
	 */
	private static void themTaiKhoan(AccountLists dsAccount) {

		Scanner scanf = new Scanner(System.in);

		Account acc;
		System.out.println("Nhập số tài khoản: ");
		long soTaiKhoan = scanf.nextLong();
		scanf.nextLine();
		System.out.println("Nhập tên tài khoản: ");
		String tenTaiKhoan = scanf.nextLine();
		System.out.println("Nhập số tiền tài khoản: ");
		double soTien;
		//validate số tiền nhập vào
		do {
			soTien = scanf.nextDouble();
			if(soTien < 0) {
				System.out.println("Số tiền không được bé hơn 0");
			}
		}while(soTien < 0);
		//nếu nhập số tiền = 0 thì thêm tài khoản mặc định (tài khoản mặc định có 50,000 đ)
		if(soTien == 0) {
			acc = new Account(soTaiKhoan, tenTaiKhoan);
		}else {
			acc = new Account(soTaiKhoan, tenTaiKhoan, soTien);
		}

		if(dsAccount.themAccount(acc) == true) {
			System.out.println("Thêm tài khoản thành công!");
		}else {
			System.out.println("Thêm thất bại! Tài khoản "+soTaiKhoan+" đã tồn tại!");
		}

	}

	private static void tieuDe() {
		System.out.println(String.format("%15s | %-25s | %15s","Số tài khoản","Tên tài khoản","Số tiền"));
	}

	private static void menu(AccountLists acc) {
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("###,000");
		int chon = 0;
		do {
			System.out.println("===============================================");
			System.out.println("MENU NGÂN HÀNG");
			System.out.println("===============================================");
			System.out.println("0. Thao tác dữ liệu cứng (Tài khoản mặc định: 1)");
			System.out.println("1. Thêm tài khoản.");
			System.out.println("2. Xuất danh sách tài khoản.");
			System.out.println("3. Nạp tiền vào tài khoản.");
			System.out.println("4. Rút tiền trong tài khoản.");
			System.out.println("5. Chuyển tiền tài khoản.");
			System.out.println("6. Đáo hạn");
			System.out.println("7. Thoát.");
			System.out.println("Chọn số? ");
			chon = sc.nextInt();
			if(chon > 7 || chon < 0) {
				System.out.println("Nhập sai!Nhập lại");

			}
			switch (chon) {
			case 1:
				System.out.println("\nTHÊM MỘT TÀI KHOẢN\n");
				themTaiKhoan(acc);
				break;
			case 2:
//				System.out.println("\nDANH SÁCH TÀI KHOẢN\n");
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);
				break;
			case 3:
				System.out.println("\nNẠP TIỀN TÀI KHOẢN\n");
				/**
				 * @Phần nạp tiền
				 */
				//step 1: input account id
				System.out.println("\nNhập số tài khoản cần nạp tiền: ");
				long taiKhoanNap = sc.nextLong();

				//step 2: search account in list if its different then recharge 
				if(acc.timAccount(taiKhoanNap) != null) {
					System.out.println("Nhập số tiền nạp vào: ");
					double soTienNapVao = sc.nextDouble();
					//begin recharge
					acc.timAccount(taiKhoanNap).napTien(soTienNapVao);
					System.out.println("Nạp số tiền " +df.format(soTienNapVao)+" vào tài khoản: "+taiKhoanNap+" - Thành công\n");
				}else {
					System.out.println("Không tìm thấy tài khoản "+taiKhoanNap);
				}

				break;
			case 4:
				System.out.println("\nRÚT TIỀN TÀI KHOẢN\n");
				/**
				 * @Phần rút tiền
				 */
				System.out.println("\nNhập số tài khoản cần rút tiền: ");
				long taiKhoanRut = sc.nextLong();

				if(acc.timAccount(taiKhoanRut) != null) {
					System.out.println("Nhập số tiền rút ra: ");
					double soTienRutRa = 0;
					//check tiền nhập vào có lớn hơn số tiền trong tài khoản  + phí rút + 50,000 hay không!
					double checkSoTienTaiKhoan = checkSoTienTrongTaiKhoan(soTienRutRa, acc, taiKhoanRut);
					//nếu không lớn hơn thì trả về số tiền => nạp vào tài khoản;
					if(checkSoTienTaiKhoan != 0) {
						soTienRutRa = checkSoTienTaiKhoan;
						acc.timAccount(taiKhoanRut).rutTien(soTienRutRa);
						System.out.println("Rút tiền "+df.format(soTienRutRa)+" từ tài khoản: "+ taiKhoanRut +" Thành công!!");
					}

				}else {
					System.out.println("Không tìm thấy tài khoản "+taiKhoanRut);
				}

				break;
			case 5:
				System.out.println("\nCHUYỂN TIỀN TÀI KHOẢN\n");
				/**
				 * @Phần chuyển tiền
				 */
				//step 1: input tranfer account & account get
				System.out.println("Nhập số tài khoản chuyển tiền");
				long taiKhoanChuyen = sc.nextLong();
				if(acc.timAccount(taiKhoanChuyen) != null) {
					System.out.println("Nhập số tài khoản nhận tiền");
					long taiKhoanNhan = sc.nextLong();
				
					if(acc.timAccount(taiKhoanNhan) != null) {

						//step 2: input money
						System.out.println("Nhập số tiền cần chuyển: ");
						double soTienChuyenDi = 0;
						double checkSoTienTaiKhoan = checkSoTienTrongTaiKhoan(soTienChuyenDi, acc, taiKhoanChuyen);

						if(checkSoTienTaiKhoan != 0) {
							soTienChuyenDi = checkSoTienTaiKhoan;
							//step 3: Chuyển tiền
							acc.timAccount(taiKhoanChuyen).chuyenTien(acc.timAccount(taiKhoanNhan), soTienChuyenDi);
							System.out.println("Chuyển "+df.format(soTienChuyenDi)+" từ tài khoản: "+taiKhoanChuyen+" qua tài khoản: "+taiKhoanNhan+" Thành công!!");
						}

					}else {
						System.out.println("Tài khoản: "+taiKhoanNhan+" Không tồn tại!");
					}
				}else {
					System.out.println("Tài khoản: "+taiKhoanChuyen+" Không tồn tại!");
				}

				break;
			case 6:
				System.out.println("\nĐáo hạn Ngân hàng\n");
				System.out.println("Nhập tài khoản đáo hạn: ");
				long soTaiKhoan = sc.nextLong();
				if(acc.timAccount(soTaiKhoan) != null) {
					acc.timAccount(soTaiKhoan).daoHan();
					System.out.println("Đáo hạn tài khoản: "+ soTaiKhoan +" Thành công!!");
				}else {
					System.out.println("Tài khoản: " + soTaiKhoan + " không tồn tại!!");
				}
				
				break;
			case 7:

				break;

			default:
				long taiKhoan = 1;
				double tienNap = 100000000;
				double tienRut = 500000;
				
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);

				acc.timAccount(taiKhoan).napTien(tienNap);
				System.out.println("Nạp tiền vào tài khoản "+taiKhoan+" với số tiền "+df.format(tienNap)+" thành công!!");
			
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);

				acc.timAccount(taiKhoan).rutTien(tienRut);
				System.out.println("Rút tiền tài khoản "+taiKhoan+" với số tiền rút "+df.format(tienRut)+" thành công!!");
				
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);

				long taiKhoanNhanTien = 2;
				double tienChuyen = 700000;
				acc.timAccount(taiKhoan).chuyenTien(acc.timAccount(taiKhoanNhanTien), tienChuyen);
				System.out.println("Chuyển tiền "+ df.format(tienChuyen) + " từ tài khoản "+taiKhoan+" sang tài khoản "+taiKhoanNhanTien+" thành công!!");
			
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);
				
				acc.timAccount(taiKhoan).daoHan();
				System.out.println("Đáo hạn tài khoản: "+taiKhoan+" Thành công!!");
				xuatDanhSach(acc.layDanhSachTaiKhoan(), acc.soPtThat);
				break;
			}
		}while(chon!= 7);
	}

	public static Double checkSoTienTrongTaiKhoan(double soTien, AccountLists acc, long soTaiKhoan) {
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("###,000");
		do {
			do {
				soTien = sc.nextDouble();
				if(soTien < 0) {
					System.out.println("Số tiền không được bé hơn 0");
				}
			}while(soTien < 0);
			
			if(soTien > acc.timAccount(soTaiKhoan).getSoTienTaiKhoan() - acc.timAccount(soTaiKhoan).TIEN_MAC_DINH - acc.timAccount(soTaiKhoan).PHI_RUT) {
				System.out.println("Số tiền trong tài khoản không đủ!! Số tiền còn: "+df.format(acc.timAccount(soTaiKhoan).getSoTienTaiKhoan()));
				System.out.println("Nhập lại số tiền: ");
			}else {
				return soTien;
			}
		}while(soTien > acc.timAccount(soTaiKhoan).getSoTienTaiKhoan() - acc.timAccount(soTaiKhoan).TIEN_MAC_DINH - acc.timAccount(soTaiKhoan).PHI_RUT);

		return (double) 0;
	}

	private static boolean kiemTraNhapNhoNhat(double soTien) {
		if(soTien < 0 ) {
			return false;
		}else {
			return true;
		}
	}
	private static void xuatDanhSach(Account[] acc, int soPhanTuThuc) {
		System.out.println("\nDANH SÁCH TÀI KHOẢN\n");
		tieuDe();
		for(int i = 0; i<soPhanTuThuc ; i++) {
			System.out.println(acc[i]);
		}
	}
}
