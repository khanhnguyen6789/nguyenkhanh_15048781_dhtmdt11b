package BaiCD;

import java.util.Arrays;
import java.util.Comparator;


public class ListCD {
	CD[] dsCD = null;
	int soPhanTuThuc;
	/**
	 * Contructor CD list
	 * @param soPhanTu
	 */
	public ListCD(int soPhanTu) {
		dsCD = new CD[soPhanTu];
	}
	
	/**
	 * Tăng kích thước
	 * Khi mảng đầy
	 */
	private void tangKichThuocMang() {
		CD[] dsCDTam = new CD[dsCD.length * 2];
		int i = 0;
		for(CD each : dsCD) {
			dsCDTam[i] = each;
			i++;
		}
		dsCD = dsCDTam;
	}
	
	public CD timCDTrongList(int maCD) {
		for(int i = 0; i<soPhanTuThuc; i++) {
			if(dsCD[i].getMaCD() == maCD) {
				return dsCD[i];
			}
		}
		return null;
	}
	
	/**
	 * Tìm vị trí của CD
	 * @param maCD
	 * @return -1 nếu ko tìm thấy
	 */
	public int timViTriCD(int maCD) {
		for(int i = 0; i<soPhanTuThuc; i++) {
			if(dsCD[i].getMaCD() == maCD) {
				return i;
			}
		}
		return -1;
	}
	
	public boolean themMotCD(CD cd) throws Exception {
		if(this.timViTriCD(cd.getMaCD()) != -1) {
			throw new Exception("Đã tồn tại");
//			return false;
		}else {
			if(soPhanTuThuc == dsCD.length) {
				this.tangKichThuocMang();
			}
			dsCD[soPhanTuThuc] = cd;
			soPhanTuThuc++;
			return true;
		}
	}
	
	public boolean suaMotCD(CD cd) {
		int viTriCD = this.timViTriCD(cd.getMaCD());
		if(viTriCD != -1) {
			dsCD[viTriCD] = cd;
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Xóa CD, nếu thành công return true
	 * @param cd
	 * @return
	 */
	public boolean xoaMotCd(int maCD) {
		int viTriCD = this.timViTriCD(maCD);
		if(viTriCD != -1) {
			System.out.println("số phần tử: "+dsCD.length);
			for(int i = viTriCD; i < dsCD.length - 1; i++) {
				dsCD[i] = dsCD[i+1];
			}
	
			soPhanTuThuc--;
			return true;
		}else {
			return false;
		}
		
	}
	
	public void sapXepTang() {
		Arrays.sort(dsCD, 0, soPhanTuThuc, new Comparator<CD>() {

			@Override
			public int compare(CD o1, CD o2) {
				// TODO Auto-generated method stub
				Integer index1 = new Integer(o1.getMaCD());
				Integer index2 = new Integer(o2.getMaCD());
				return index1.compareTo(index2);
			}
		});
	}
	
	public void sapXepGiam() {
		Arrays.sort(dsCD, 0, soPhanTuThuc, new Comparator<CD>() {

			@Override
			public int compare(CD o1, CD o2) {
				// TODO Auto-generated method stub
				Integer index1 = new Integer(o1.getMaCD());
				Integer index2 = new Integer(o2.getMaCD());
				return index2.compareTo(index1);
			}
		});
	}
	
	/**
	 * Trùng tựa thì sắp xếp theo giá thành
	 */
	public void sapXepTheoTua() {
		Arrays.sort(dsCD,0,soPhanTuThuc,new Comparator<CD>() {
			
			@Override
			public int compare(CD o1, CD o2) {
				Float d1=new Float( o1.getGiaThanh());
				Float d2= new Float( o2.getGiaThanh());
				int s= d1.compareTo(d2);	
				return (s == 0) ? o1.getTuaCD().compareToIgnoreCase(o2.getTuaCD()) : s;
			}
		});
	}
	
	public CD[] layDanhSachCD() {
		return dsCD;
	}
}
