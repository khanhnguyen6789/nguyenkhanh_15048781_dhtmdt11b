package tuan2_Bai4_Account;

import java.text.DecimalFormat;

public class Account {
	private long soTaiKhoan;
	private String tenTaiKhoan;
	private double soTienTaiKhoan;
	private final double LAI_SUAT = 0.035;
	public final double PHI_RUT = 1000;
	public final double TIEN_MAC_DINH = 50000;
	public long getSoTaiKhoan() {
		return soTaiKhoan;
	}
	public void setSoTaiKhoan(long soTaiKhoan) {
		this.soTaiKhoan = soTaiKhoan;
	}
	public String getTenTaiKhoan() {
		return tenTaiKhoan;
	}
	public void setTenTaiKhoan(String tenTaiKhoan) {
		this.tenTaiKhoan = tenTaiKhoan;
	}
	public double getSoTienTaiKhoan() {
		return soTienTaiKhoan;
	}
	public void setSoTienTaiKhoan(double soTienTaiKhoan) {
		this.soTienTaiKhoan = soTienTaiKhoan;
	}
	public Account(long soTaiKhoan, String tenTaiKhoan, double soTienTaiKhoan) {
		super();
		this.soTaiKhoan = soTaiKhoan;
		this.tenTaiKhoan = tenTaiKhoan;
		this.soTienTaiKhoan = soTienTaiKhoan;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @contructor use when create
	 * @param soTaiKhoan
	 * @param tenTaiKhoan
	 */
	public Account(long soTaiKhoan, String tenTaiKhoan) {
		super();
		this.soTaiKhoan = soTaiKhoan;
		this.tenTaiKhoan = tenTaiKhoan;
		this.soTienTaiKhoan = TIEN_MAC_DINH;
	}
	/**
	 * @Nạp tiền
	 * @param tienNap
	 */
	public void napTien(double tienNap) {
		double currentMoney  = this.getSoTienTaiKhoan();
		currentMoney += tienNap;
		this.setSoTienTaiKhoan(currentMoney);
	}
	/**
	 * @Rút tiền
	 * @param tienRut
	 */
	public void rutTien(double tienRut) {
		double currentMoney  = this.getSoTienTaiKhoan();
		currentMoney -= tienRut + PHI_RUT;
		this.setSoTienTaiKhoan(currentMoney);
	}
	public void daoHan() {
		double currentMoney = this.getSoTienTaiKhoan();
		currentMoney = currentMoney + currentMoney * LAI_SUAT;
		this.setSoTienTaiKhoan(currentMoney);
	}
	public void chuyenTien(Account account, double tienChuyen) {
		//step 1 : rút tiền
		this.rutTien(tienChuyen);
		//step 2 : nạp tiền tài khoản nhận
		account.napTien(tienChuyen);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		DecimalFormat df = new DecimalFormat("###,000");
		return String.format("%15d | %-25s | %15s", this.getSoTaiKhoan(),this.getTenTaiKhoan(),df.format(this.getSoTienTaiKhoan()));
	}
}
