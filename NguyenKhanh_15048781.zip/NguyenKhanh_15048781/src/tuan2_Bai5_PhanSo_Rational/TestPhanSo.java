package tuan2_Bai5_PhanSo_Rational;

import java.util.Scanner;

public class TestPhanSo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Rational phanSo1 =null;
//		Rational phanSo2 =null;
		menu();

	}
	private static void menu() {
		Rational ps1 = new Rational(1, 1);Rational ps2 = new Rational(1,1);
		Scanner sc = new Scanner(System.in);
		
		int chon = 0;
		do {
			System.out.println("1. Nhập 2 Phân số");
			System.out.println("2. Xuất chương trình tính Phân số");
			System.out.println("Chọn số? :");
			chon = sc.nextInt();
			switch (chon) {
			case 1:
				System.out.println("Nhập phân số thứ nhất");
				System.out.println("Nhập tử số :");
				int tuSo1 = sc.nextInt();
				System.out.println("Nhập mẫu số :");
				int mauSo1 = sc.nextInt();
				ps1 = new Rational(tuSo1, mauSo1);
				System.out.println("Nhập phân số thứ hai");
				System.out.println("Nhập tử số :");
				int tuSo2 = sc.nextInt();
				System.out.println("Nhập mẫu số :");
				int mauSo2 = sc.nextInt();
				ps2 = new Rational(tuSo2, mauSo2);
				break;
			case 2:
				System.out.println("\nCHƯƠNG TRÌNH HAI PHÂN SỐ\n");
				System.out.println("\n================================\n");
				System.out.println("\nCộng 2 phân số:");
				System.out.println(ps1.congPhanSo(ps2));
				
				System.out.println("\nTrừ 2 phân số:");
				System.out.println(ps1.truPhanSo(ps2));
				
				System.out.println("\nNhân 2 phân số:");
				System.out.println(ps1.nhanPhanSo(ps2));
				
				System.out.println("\nChia 2 phân số:");
				System.out.println(ps1.chiaPhanSo(ps2));
				
				System.out.println("\nSo Sánh phân số:");
				System.out.println(ps1.soSanhPhanSo(ps2));
				
				System.out.println("\nNghịch đảo phân số:");
				System.out.println("Phân số 1: \n"+ps1.nghichDaoPhanSo()+"\nPhân số 2:\n"+ps2.nghichDaoPhanSo());
				break;
				
			case 3:
				break;
			default:
				break;
			}
			if(chon > 2) {
				System.out.println("Chọn sai!! Vui lòng chọn lại: ");
				chon = sc.nextInt();
			}
		}while(chon != 3);
	}
	private static void tieuDe(int n) {
		System.out.println("Phân Số "+n);
	}
}
