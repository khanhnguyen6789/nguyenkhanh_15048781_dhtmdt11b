package tuan2_Bai5_PhanSo_Rational;

public class Rational {
	private int tuSo,mauSo;//tuSo : tử số ; mauSo : mẫu số 

	public int getTuSo() {
		return tuSo;
	}

	public void setTuSo(int tuSo) {
		this.tuSo = tuSo;
	}

	public int getMauSo() {
		return mauSo;
	}

	public void setMauSo(int mauSo) {
		this.mauSo = mauSo;
	}

	public Rational(int tuSo, int mauSo) {
		super();
		this.tuSo = tuSo;
		this.mauSo = mauSo;
	}

	public Rational() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int timUCLN(int a, int b) {
			while (a != b) {
			if(a > b) {
				a -= b;
			}else {
				b -= a;
			}
		}
		return a;
	}
	
	public String congPhanSo(Rational phanSo2) {
		int tuSoMoi,mauSoMoi,tuSoToiGian,mauSoToiGian;
		tuSoMoi = this.getTuSo() * phanSo2.getMauSo() + phanSo2.getTuSo() * this.getMauSo();
		mauSoMoi = this.getMauSo() * phanSo2.getMauSo();
		Rational phanSoMoi = new Rational(tuSoMoi, mauSoMoi);

		phanSoMoi.toiGianPhanSo();
		tuSoToiGian = phanSoMoi.getTuSo();
		mauSoToiGian = phanSoMoi.getMauSo();
		
		if(mauSoToiGian == 1) {
			return String.format("%3d   %3d\n%3s%3s%3s%3s%3d\n%3d   %3d", this.getTuSo(),phanSo2.getTuSo(),"-","+","-","=",tuSoToiGian,this.getMauSo(),phanSo2.getMauSo());
		}else {
			return String.format("%3d   %3d   %3d\n%3s%3s%3s%3s%3s\n%3d   %3d   %3d", this.getTuSo(),phanSo2.getTuSo(),tuSoToiGian,"-","+","-","=","-",this.getMauSo(),phanSo2.getMauSo(),mauSoToiGian);

		}
		
	}
	
	public String truPhanSo(Rational phanSo2) {
		int tuSoMoi,mauSoMoi,tuSoToiGian,mauSoToiGian;
		tuSoMoi = this.getTuSo() * phanSo2.getMauSo() - phanSo2.getTuSo() * this.getMauSo();
		mauSoMoi = this.getMauSo() * phanSo2.getMauSo();
		Rational phanSoMoi = new Rational(tuSoMoi, mauSoMoi);

		phanSoMoi.toiGianPhanSo();
		tuSoToiGian = phanSoMoi.getTuSo();
		mauSoToiGian = phanSoMoi.getMauSo();

//		tuSoToiGian = tuSoMoi;
//		mauSoToiGian = mauSoMoi;
		if(mauSoToiGian == 1) {
			return String.format("%3d   %3d\n%3s%3s%3s%3s%3d\n%3d   %3d", this.getTuSo(),phanSo2.getTuSo(),"-","-","-","=",tuSoToiGian,this.getMauSo(),phanSo2.getMauSo());
		}else {
			return String.format("%3d   %3d   %3d\n%3s%3s%3s%3s%3s\n%3d   %3d   %3d", this.getTuSo(),phanSo2.getTuSo(),tuSoToiGian,"-","-","-","=","-",this.getMauSo(),phanSo2.getMauSo(),mauSoToiGian);

		}
		
	}
	
	public String nhanPhanSo(Rational phanSo2) {
		int tuSoMoi,mauSoMoi,tuSoToiGian,mauSoToiGian;
		tuSoMoi = this.getTuSo() * phanSo2.getTuSo();
		mauSoMoi = this.getMauSo() * phanSo2.getMauSo();
		Rational phanSoMoi = new Rational(tuSoMoi, mauSoMoi);

		phanSoMoi.toiGianPhanSo();
		tuSoToiGian = phanSoMoi.getTuSo();
		mauSoToiGian = phanSoMoi.getMauSo();
		
		if(mauSoToiGian == 1) {
			return String.format("%3d   %3d\n%3s%3s%3s%3s%3d\n%3d   %3d", this.getTuSo(),phanSo2.getTuSo(),"-","x","-","=",tuSoToiGian,this.getMauSo(),phanSo2.getMauSo());
		}else {
			return String.format("%3d   %3d   %3d\n%3s%3s%3s%3s%3s\n%3d   %3d   %3d", this.getTuSo(),phanSo2.getTuSo(),tuSoToiGian,"-","x","-","=","-",this.getMauSo(),phanSo2.getMauSo(),mauSoToiGian);

		}
		
	}
	
	public String chiaPhanSo(Rational phanSo2) {
		int tuSoMoi,mauSoMoi,tuSoToiGian,mauSoToiGian;
		tuSoMoi = this.getTuSo() * phanSo2.getMauSo();
		mauSoMoi = this.getMauSo() * phanSo2.getTuSo();
		Rational phanSoMoi = new Rational(tuSoMoi, mauSoMoi);

		phanSoMoi.toiGianPhanSo();
		tuSoToiGian = phanSoMoi.getTuSo();
		mauSoToiGian = phanSoMoi.getMauSo();
		
		if(mauSoToiGian == 1) {
			return String.format("%3d   %3d\n%3s%3s%3s%3s%3d\n%3d   %3d", this.getTuSo(),phanSo2.getTuSo(),"-",":","-","=",tuSoToiGian,this.getMauSo(),phanSo2.getMauSo());
		}else {
			return String.format("%3d   %3d   %3d\n%3s%3s%3s%3s%3s\n%3d   %3d   %3d", this.getTuSo(),phanSo2.getTuSo(),tuSoToiGian,"-",":","-","=","-",this.getMauSo(),phanSo2.getMauSo(),mauSoToiGian);

		}
		
	}
	
	public String nghichDaoPhanSo() {
		int tuSoMoi,mauSoMoi;
		tuSoMoi = this.mauSo;
		mauSoMoi = this.tuSo;
		return String.format("%d\n%s\n%d", tuSoMoi,"-",mauSoMoi);
	}
	
	public String soSanhPhanSo(Rational phanSo2) {
		int tuSoPhanSo1,tuSoPhanSo2;
		String dauSoSanh = null;
		tuSoPhanSo1 = this.getTuSo() * phanSo2.getMauSo();
		tuSoPhanSo2 = phanSo2.tuSo * this.getMauSo();
		
		if(tuSoPhanSo1 > tuSoPhanSo2) {
			dauSoSanh = ">";
		}else if (tuSoPhanSo1 < tuSoPhanSo2) {
			dauSoSanh = "<";
		}else {
			dauSoSanh = "=";
		}
		return String.format("%3d   %3d\n%3s%3s%3s\n%3d   %3d", this.getTuSo(),phanSo2.getTuSo(),"-",dauSoSanh,"-",this.getMauSo(),phanSo2.getMauSo());
	}
	public void toiGianPhanSo() {
	
		int UCLN = timUCLN(Math.abs(this.getTuSo()),Math.abs(this.getMauSo()));
		int tuSoMoi,mauSoMoi;
//		System.out.println("UCLN: "+UCLN);
//		if(UCLN > 0) {
			tuSoMoi = this.getTuSo() / UCLN;
			
			mauSoMoi = this.getMauSo() / UCLN;
			this.setTuSo(tuSoMoi);
			this.setMauSo(mauSoMoi);

//		}else {
//			this.setTuSo(this.getTuSo());
//			this.setMauSo(this.getMauSo());
//		}
		
		
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%d \n-\n%d", this.getTuSo() , this.mauSo);

	}
}
