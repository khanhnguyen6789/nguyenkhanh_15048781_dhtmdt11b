package tuan1_Bai2_SinhVien;

public class SinhVien {
	private int maSinhVien;
	private String hoTenSinhVien;
	private float diemLT,diemTH;
	public int getmaSinhVien() {
		return maSinhVien;
	}
	public void setmaSinhVien(int maSinhVien) {
		this.maSinhVien = maSinhVien;
	}
	public String gethoTenSinhVien() {
		return hoTenSinhVien;
	}
	public void sethoTenSinhVien(String hoTenSinhVien) {
		this.hoTenSinhVien = hoTenSinhVien;
	}
	public float getDiemLT() {
		return diemLT;
	}
	public void setDiemLT(float diemLT) {
		this.diemLT = diemLT;
	}
	public float getDiemTH() {
		return diemTH;
	}
	public void setDiemTH(float diemTH) {
		this.diemTH = diemTH;
	}
	public SinhVien(int maSinhVien, String hoTenSinhVien, float diemLT, float diemTH) {
		super();
		this.maSinhVien = maSinhVien;
		this.hoTenSinhVien = hoTenSinhVien;
		this.diemLT = diemLT;
		this.diemTH = diemTH;
	}
	public SinhVien() {
		super();
		// TODO Auto-generated constructor stub
	}
	public float tinhDiemTB() {
		float diemTB;
		return diemTB = (this.getDiemLT() + this.getDiemTH()) /2;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%-12d | %-30s | %-10.2f | %-10.2f | %-10.2f", this.getmaSinhVien(),this.gethoTenSinhVien(),this.diemLT,this.diemTH,this.tinhDiemTB());
	}
}
