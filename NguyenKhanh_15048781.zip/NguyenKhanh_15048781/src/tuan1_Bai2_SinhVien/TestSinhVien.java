package tuan1_Bai2_SinhVien;

import java.util.Scanner;

public class TestSinhVien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanf = new Scanner(System.in);
		SinhVien sv1 = new SinhVien(15020551, "Tống Minh Thuận", 6, 7);
		SinhVien sv2 = new SinhVien(15020552, "Bạn thân Tống Minh Thuận", 7, 8);
		
		tieuDe();
		System.out.println(sv1);
		System.out.println(sv2);
		
		SinhVien sv3 = new SinhVien();
		System.out.println("\nNhập mã sinh viên: ");
		sv3.setmaSinhVien(scanf.nextInt());
		scanf.nextLine();
		System.out.println("\nNhập họ tên sinh viên: ");
		sv3.sethoTenSinhVien(scanf.nextLine());
		System.out.println("\nNhập điểm lý thuyết: ");
		sv3.setDiemLT(scanf.nextFloat());
		System.out.println("\nNhập điểm thực hành: ");
		sv3.setDiemTH(scanf.nextFloat());
		tieuDe();
		System.out.println(sv1);
		System.out.println(sv2);
		System.out.println(sv3);
	}
	
	public static void tieuDe() {
		System.out.println(String.format("%-12s | %-30s | %-10s | %-10s | %-10s","Mã SV","Tên SV","Điểm LT","Điểm TH","Điểm TB"));
	}
}
