package tuan1_Bai3_Vehicle;

import java.util.Scanner;

public class TestVehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanf = new Scanner(System.in);
		int chon = 0;
		Vehicle xe1 = new Vehicle("Tống Minh Thuận", "Wave 150", 150, 35000000);
		Vehicle xe2 = new Vehicle("Hoàn Thanh Phong Trần", "Exciter 150", 150, 55000000);
		Vehicle xe3 = new Vehicle("Kim Jong Un", "Kawasaki z1000", 1000, 405000000);
		
		Vehicle xeInput = null;
		
		do {
			System.out.println("\nMenu\n");
			System.out.println("\n1. Nhập thông tin.");
			System.out.println("\n2. Xuất bảng kê khai trước bạ.");
			System.out.println("\n3. Thoát.");
			System.out.println("\nBạn chọn số mấy?: ");
			chon = scanf.nextInt();
			switch (chon) {
			case 1:
				xeInput = nhapVehicle();
				break;
			case 2:
				tieuDe();
				System.out.println(xe1);
				System.out.println(xe2);
				System.out.println(xe3);
				System.out.println(xeInput);
				
				break;
			case 3:
			
				break;
			default:
				System.out.println("\n Welcome to my APP\n");
				
				break;
			}
		}while(chon !=3);
		
	}
	
	private static Vehicle nhapVehicle() {
		String tenChuXe,tenLoaiXe;
		int dungTichCC;
		float giaTri;
		Scanner scanf = new Scanner(System.in);
		System.out.println("\n Nhập tên chủ xe: ");
		tenChuXe = scanf.nextLine();
		System.out.println("\n Nhập loại xe: ");
		tenLoaiXe = scanf.nextLine();
		System.out.println("\n Nhập dung tích xe: ");
		dungTichCC = scanf.nextInt();
		System.out.println("\n Nhập trị giá xe: ");
		giaTri = scanf.nextFloat();
		Vehicle vh = new Vehicle(tenChuXe, tenLoaiXe, dungTichCC, giaTri);
		return vh;
	}
	
	/*
	 * @print head
	 */
	private static void tieuDe() {
		// TODO Auto-generated method stub
		System.out.println(String.format("%-30s | %-20s | %-10s | %-15s | %-15s","Tên chủ xe","Loại xe","Dung tích","Trị giá","Thuê phải nộp"));
	}

}
