package tuan1_Bai3_Vehicle;

public class Vehicle {
	private String tenChuXe,tenLoaiXe;
	private int dungTichCC;
	private float giaTri;
	public String getTenChuXe() {
		return tenChuXe;
	}
	public void setTenChuXe(String tenChuXe) {
		this.tenChuXe = tenChuXe;
	}
	public String getTenLoaiXe() {
		return tenLoaiXe;
	}
	public void setTenLoaiXe(String tenLoaiXe) {
		this.tenLoaiXe = tenLoaiXe;
	}
	public int getDungTichCC() {
		return dungTichCC;
	}
	public void setDungTichCC(int dungTichCC) {
		this.dungTichCC = dungTichCC;
	}
	public float getGiaTri() {
		return giaTri;
	}
	public void setGiaTri(float giaTri) {
		this.giaTri = giaTri;
	}
	public Vehicle(String tenChuXe, String tenLoaiXe, int dungTichCC, float giaTri) {
		super();
		this.tenChuXe = tenChuXe;
		this.tenLoaiXe = tenLoaiXe;
		this.dungTichCC = dungTichCC;
		this.giaTri = giaTri;
	}
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double tinhThue() {
		double thue = 0;
		if(this.getDungTichCC() < 100) {
			thue = (this.getGiaTri() * 1)/100;
		}else if (this.getDungTichCC() >= 100 && this.getDungTichCC() <= 200 ) {
			thue = (this.getGiaTri() * 3)/100;
		}else {
			thue = (this.getGiaTri() * 5)/100;
		}
		return thue;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%-30s | %-20s | %10d | %15.2f | %15.2f",this.getTenChuXe(),this.getTenLoaiXe(),this.getDungTichCC(),this.getGiaTri(),this.tinhThue());
	}
}
