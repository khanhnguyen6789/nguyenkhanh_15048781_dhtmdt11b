package BaiCD;

import java.util.Scanner;


public class testCD {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListCD dsCD = new ListCD(3);
		CD cd1 = new CD(10, 10, "52 ký lô", "Lăng LD", 100000);
		CD cd2 = new CD(2, 10, "Big CITYBOI", "Binz", 500000);
		CD cd3 = new CD(3, 10, "Missing You", "G-Dragon", 1500000);
		CD cd4 = new CD(4, 10, "52 ký lô", "Lăng LD", 100000);
		CD cd5 = new CD(5, 10, "Big CITYBOI", "Binz", 500000);
		CD cd6 = new CD(6, 10, "Missing You", "G-Dragon", 1500000);
		try {
			dsCD.themMotCD(cd1);
			dsCD.themMotCD(cd2);
			dsCD.themMotCD(cd3);
			dsCD.themMotCD(cd4);
			dsCD.themMotCD(cd5);
			dsCD.themMotCD(cd6);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			
		try {		

			menuCD(dsCD);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Lỗi chương trình! Chương trình dừng");
		}

	}

	public static void menuCD(ListCD dsCD) {
		int chon = 0;
		do
		{
			System.out.println("1. Thêm 1 CD.");
			System.out.println("2. Thêm nhiều CD.");
			System.out.println("3. Sửa CD.");
			System.out.println("4. Xóa 1 CD.");
			System.out.println("5. Xuất danh sách.");
			System.out.println("6. Thoát.");
			System.out.println("7. Sắp xếp.");
			System.out.println("Chọn số?: ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 7) {
				System.out.println("Chọn Sai!! Chọn số(1 đến 5): ");
			}else {

				switch (chon) {
				case 1:
					System.out.println("Nhập mã: ");
					int maCDCheck = 0;
					int maCD = nhapSo(maCDCheck,"Mã CD");
					sc.nextLine();

					System.out.println("Nhập tựa CD: ");
					String tuaCDCheck = null;
					String tuaCD = nhap1(tuaCDCheck,"Tựa CD");

					System.out.println("Nhập tên Ca Sĩ: ");
					String tenCaSiCheck = null;
					String tenCaSi = nhap1(tenCaSiCheck,"Ca Sĩ");

					System.out.println("Nhập số bài hát: ");
					int soBaiHatCheck = 0;
					int soBaiHat = nhapSo(soBaiHatCheck,"Bài hát");

					System.out.println("Nhập Giá Thành: ");
					int giaThanhCheck = 0;
					float giaThanh = (float) nhapSo(giaThanhCheck,"Giá Thành");
					CD cd = new CD(maCD, soBaiHat, tuaCD, tenCaSi, giaThanh);

					try {
						if(dsCD.themMotCD(cd) == true) {
							System.out.println("Thêm thành công");
						}else {
							System.out.println("Mã " + maCD + " - Đã tồn tại!!");
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					break;
				case 2:

					break;
				case 3:
					System.out.println("Nhập mã CD cần sửa: ");
					int maCDTim = sc.nextInt();
					sc.nextLine();
					if(dsCD.timCDTrongList(maCDTim) != null) {
						System.out.println("Nhập tựa CD: ");
						String tuaCDSua = sc.nextLine();
						System.out.println("Nhập tên Ca Sĩ: ");
						String tenCaSiSua = sc.nextLine();
						System.out.println("Nhập số bài hát: ");
						int soBaiHatSua = sc.nextInt();
						System.out.println("Nhập Giá Thành: ");
						float giaThanhSua = sc.nextFloat();
						CD cdSua = new CD(maCDTim, soBaiHatSua, tuaCDSua, tenCaSiSua, giaThanhSua);
						dsCD.suaMotCD(cdSua);
					}else {
						System.out.println("Không tìm thấy mã: " + maCDTim);
					}

					break;
				case 4:
					System.out.println("Nhập mã CD cần xóa: ");
					int maCDXoa = sc.nextInt();
					if(dsCD.xoaMotCd(maCDXoa)) {
						System.out.println("Xóa thành công");
					}else {
						System.out.println("Xóa thất bại!! Mã " +maCDXoa+" Không tồn tại!");
					}
					break;
				case 7:

					break;
				case 5:
					xuatDanhSach(dsCD.layDanhSachCD(),dsCD.soPhanTuThuc);
					break;
				default:
					break;
				}
			}
		}while(chon != 6);
	}

	public static void tieuDe() {
		System.out.println(String.format("%15s | %20s | %20s | %10s | %25s", "Mã CD", "Tựa CD", "Tên Ca Sĩ", "Số bài hát", "Giá Thành"));
	}
	public static void xuatDanhSach(CD[] dsCD,int soPhanTuThuc) {
		tieuDe();
		if(soPhanTuThuc > 0) {
			for(int i = 0 ; i< soPhanTuThuc ; i++) {
				System.out.println(dsCD[i]);
			}
		}else {
			System.out.println("\t\t\t\t\t\t\t Danh sách rỗng ");
		}
	}

	public static String nhap1(String str,String errorMessage) {

		do {
			str = sc.nextLine();
			if(str == null || str.isEmpty()) {
				System.out.println(errorMessage + " Không được để trống!\nNhập lại " + errorMessage);
			}
		}while(str == null || str.isEmpty());
		return str;
	}

	public static int nhapSo(int num,String errorMessage) {
		try {
			do {
				num = sc.nextInt();
				if(num < 0) {
					System.out.println(errorMessage+" Không được bé hơn 0!!\nNhập lại " + errorMessage);
				}
			}while(num < 0);
		}catch (Exception e) {
			System.out.println("ko phai so");
			throw null;
		}
		
		return num;
	}
}
