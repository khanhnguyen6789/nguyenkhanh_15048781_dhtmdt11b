package tuan3_M3_Bai1_ChuyenXe;

import java.text.DecimalFormat;

public class ChuyenXe {
	protected String maXe,hoTenTaiXe, soXe;
	protected double doanhThu;
	public String getMaXe() {
		return maXe;
	}
	public void setMaXe(String maXe) {
		this.maXe = maXe;
	}
	public String getHoTenTaiXe() {
		return hoTenTaiXe;
	}
	public void setHoTenTaiXe(String hoTenTaiXe) {
		this.hoTenTaiXe = hoTenTaiXe;
	}
	public String getSoXe() {
		return soXe;
	}
	public void setSoXe(String soXe) {
		this.soXe = soXe;
	}
	public double getDoanhThu() {
		return doanhThu;
	}
	public void setDoanhThu(double doanhThu) {
		this.doanhThu = doanhThu;
	}
	public ChuyenXe(String maXe, String hoTenTaiXe, String soXe, double doanhThu) {
		super();
		this.maXe = maXe;
		this.hoTenTaiXe = hoTenTaiXe;
		this.soXe = soXe;
		this.doanhThu = doanhThu;
	}
	
	public ChuyenXe(String maXe, String hoTenTaiXe, String soXe) {
		super();
		this.maXe = maXe;
		this.hoTenTaiXe = hoTenTaiXe;
		this.soXe = soXe;
		this.doanhThu = 0;
	}
	public ChuyenXe() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maXe == null) ? 0 : maXe.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChuyenXe other = (ChuyenXe) obj;
		if (maXe == null) {
			if (other.maXe != null)
				return false;
		} else if (!maXe.equals(other.maXe))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		DecimalFormat df = new DecimalFormat("###,000");
		return String.format("%15s | %25s | %15s | %15s", this.getMaXe(), this.getHoTenTaiXe(), this.getSoXe(), df.format(this.getDoanhThu()));
	}
}
