package tuan3_M3_Bai1_ChuyenXe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class DanhSachChuyenXe {
	List<ChuyenXe> dsChuyenXe = new ArrayList<ChuyenXe>();
	public boolean addChuyenXe(ChuyenXe cx) {

		if(dsChuyenXe.indexOf(cx) != -1) {
			return false;
		}else {
			dsChuyenXe.add(cx);
			return true;
		}
	}
	
	public double tongTienDoanhThuNoiThanh() {
		double tong = 0;
		for(ChuyenXe row:dsChuyenXe)
		{
			if(row instanceof ChuyenXeNoiThanh) {
				tong+=row.getDoanhThu();
			}
		}
		return tong;
	}
	
	public void sapXep() {
		Collections.sort(dsChuyenXe, new Comparator<ChuyenXe>() {

			@Override
			public int compare(ChuyenXe o1, ChuyenXe o2) {
				// TODO Auto-generated method stub
				return o1.getMaXe().compareToIgnoreCase(o2.getMaXe());
			}
		});
	}
	
	public double tongTienDoanhThuNgoaiThanh() {
		double tong = 0;
		for(ChuyenXe row:dsChuyenXe)
		{
			if(row instanceof ChuyenXeNgoaiThanh) {
				tong+=row.getDoanhThu();
			}
		}
		return tong;
	}
	
	public List<ChuyenXe> getAllList() {
		return dsChuyenXe;
	}
}
