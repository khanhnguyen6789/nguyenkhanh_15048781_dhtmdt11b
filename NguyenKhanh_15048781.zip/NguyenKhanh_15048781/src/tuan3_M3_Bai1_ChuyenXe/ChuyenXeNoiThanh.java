package tuan3_M3_Bai1_ChuyenXe;



public class ChuyenXeNoiThanh extends ChuyenXe{
	private String soTuyen;
	private double soKmDiDuoc;
	public String getSoTuyen() {
		return soTuyen;
	}
	public void setSoTuyen(String soTuyen) {
		this.soTuyen = soTuyen;
	}
	public double getSoKmDiDuoc() {
		return soKmDiDuoc;
	}
	public void setSoKmDiDuoc(double soKmDiDuoc) {
		this.soKmDiDuoc = soKmDiDuoc;
	}
	public ChuyenXeNoiThanh(String maXe, String hoTenTaiXe, String soXe, double doanhThu, String soTuyen,
			double soKmDiDuoc) {
		super(maXe, hoTenTaiXe, soXe, doanhThu);
		this.soTuyen = soTuyen;
		this.soKmDiDuoc = soKmDiDuoc;
	}
	public ChuyenXeNoiThanh() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ChuyenXeNoiThanh(String maXe, String hoTenTaiXe, String soXe, double doanhThu) {
		super(maXe, hoTenTaiXe, soXe, doanhThu);
		// TODO Auto-generated constructor stub
	}
	public ChuyenXeNoiThanh(String maXe, String hoTenTaiXe, String soXe) {
		super(maXe, hoTenTaiXe, soXe);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub

		String stringNoiThanh = String.format(" | %-22s | %-15s | %15.0f | %-20s | %-20s","Chuyến xe nội thành", this.getSoTuyen(), this.getSoKmDiDuoc(),"","");
		return super.toString() + stringNoiThanh;
	}
}
