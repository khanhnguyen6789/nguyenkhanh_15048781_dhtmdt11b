package tuan3_M3_Bai1_ChuyenXe;

import java.text.DecimalFormat;

import java.util.Scanner;

public class TestChuyenXe {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			DanhSachChuyenXe dsChuyenXe = new DanhSachChuyenXe();
			menuChuyenXe(dsChuyenXe);
		}catch (Exception e) {
			System.out.println("Lỗi chương trình!! Chương trình dừng lại,");
		}
		
	}

	public static void nhapCungChuyenXe(DanhSachChuyenXe dsChuyenXe) {
		ChuyenXeNgoaiThanh chuyenXe4 = new ChuyenXeNgoaiThanh("2", "Xe Ngoại Thành 4", "70k-7575", 2000000, "Tây Ninh", 2);
		ChuyenXeNgoaiThanh chuyenXe5 = new ChuyenXeNgoaiThanh("5", "Xe Ngoại Thành 5", "70k-8585", 3000000, "Ninh Thuận", 1);
		ChuyenXeNgoaiThanh chuyenXe1 = new ChuyenXeNgoaiThanh("1", "Xe Ngoại Thành 1", "70k-7575", 1000000, "Đồng Tháp", 2);
		ChuyenXeNgoaiThanh chuyenXe2 = new ChuyenXeNgoaiThanh("2", "Xe Ngoại Thành 2", "70k-8585", 2000000, "Long An", 1);
		ChuyenXeNgoaiThanh chuyenXe3 = new ChuyenXeNgoaiThanh("3", "Xe Ngoại Thành 3", "70k-7575", 3000000, "Cà Mau", 2);


		ChuyenXeNoiThanh chuyenXe6 = new ChuyenXeNoiThanh("6", "Xe nội thành 1", "81A-78954", 5000000, "Tuyến 2", 100);
		ChuyenXeNoiThanh chuyenXe7 = new ChuyenXeNoiThanh("7", "Xe nội thành 2", "59B-87954", 7000000, "Tuyến 4", 200);

		
		dsChuyenXe.addChuyenXe(chuyenXe2);
		dsChuyenXe.addChuyenXe(chuyenXe3);
		dsChuyenXe.addChuyenXe(chuyenXe4);
		dsChuyenXe.addChuyenXe(chuyenXe5);
		dsChuyenXe.addChuyenXe(chuyenXe6);
		dsChuyenXe.addChuyenXe(chuyenXe7);
		dsChuyenXe.addChuyenXe(chuyenXe1);
	
		xuatDanhSach(dsChuyenXe);
		xuatDoanhThu(dsChuyenXe);
	}
	public static void xuatDanhSach(DanhSachChuyenXe dsChuyenXe) {
		tieuDe();
		dsChuyenXe.sapXep();
		for(ChuyenXe row : dsChuyenXe.getAllList()) {
			System.out.println(row);
		}
		
		System.out.println("\n");
	}
	private static void tieuDe() {//	mã		tên		số xe	doanhthu  loại sotuyn sokm   noiden  ngaydiduoc
		System.out.println(String.format("%15s | %25s | %15s | %-15s | %-22s | %-15s | %-15s | %-20s | %-20s", "Mã Xe","Tên tài xế","Số xe","Doanh Thu","Loại Chuyến Xe", "Số Tuyến", "Số Km đi được","Nơi Đến","Ngày Đi Được"));
	}
	private static void xuatDoanhThu(DanhSachChuyenXe ds) {
		DecimalFormat fm= new DecimalFormat("###,000");
	
		System.out.println("Tổng tiền xe Nội Thành: " + fm.format(ds.tongTienDoanhThuNoiThanh()));
		System.out.println("Tổng tiền xe Ngoại Thành: "+ fm.format(ds.tongTienDoanhThuNgoaiThanh()));
		System.out.println("\n");
	}

	private static void tieuDeMenuChuyenXe() {
		System.out.println("MENU CHUYẾN XE");
		System.out.println("1. Nhập cứng Chuyến Xe.");
		System.out.println("2. Nhập mới Chuyến Xe.");
		System.out.println("3. Xuất Danh sách chuyến xe.");
		System.out.println("4. Thoát.");
	}
	
	private static void tieuDeChonNhapChuyenXe() {
		System.out.println("CHỌN PHƯƠNG THỨC NHẬP CHUYẾN XE");
		System.out.println("1. Nhập một chuyến xe Ngoại Thành.");
		System.out.println("2. Nhập một chuyến xe Nội Thành.");
		System.out.println("3. Thoát.");
	}
	
	private static void menuChonNhapChuyenXe(DanhSachChuyenXe dsChuyenXe) {
		int chon;
		do {
			tieuDeChonNhapChuyenXe();
			System.out.println("Bạn chọn số? ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 3) {
				System.out.println("Chọn sai! ");
				tieuDeChonNhapChuyenXe();
				System.out.println("Chọn lại từ (1 đến 3): ");
			}else {
				switch (chon) {
				case 1:
					System.out.println("NHẬP CHUYẾN XE NGOẠI THÀNH\n");
					int ngoaiThanh = 1;
					sc.nextLine();
					nhapMemChuyenXe(dsChuyenXe,ngoaiThanh);
					chon = 3;
					break;
				case 2:
					System.out.println("NHẬP CHUYẾN XE NỘI THÀNH\n");
					int noiThanh = 2;
					sc.nextLine();
					nhapMemChuyenXe(dsChuyenXe,noiThanh);
					chon = 3;
					break;
				default:
					break;
				}
			}
		}while(chon != 3);
	}
	
	private static void nhapMemChuyenXe(DanhSachChuyenXe dsChuyenXe, int loaiXe) {
		int ngoaiThanh = 1,noiThanh = 2;

		System.out.println("Nhập mã xe: ");
		String checkMaXe = "";
		String maXe = nhapChuoi(checkMaXe, "mã xe");
		System.out.println("Nhập họ tên tài xế: ");
		String checkHoTenTaiXe = null;
		String hoTenTaiXe = nhapChuoi(checkHoTenTaiXe, "họ tên tài xế");
		System.out.println("Nhập số xe: ");
		String checkSoXe = null;
		String soXe = nhapChuoi(checkSoXe, "số xe");
		System.out.println("Nhập doanh thu: ");
		long checkDoanhThu = 0;
		double doanhThu = (double) nhapSo(checkDoanhThu, "doanh thu");
		sc.nextLine();
		if(loaiXe == ngoaiThanh) {
			System.out.println("Nhập nơi đến: ");
			String checkNoiDen = null;
			String noiDen = nhapChuoi(checkNoiDen, "nơi đến");
			System.out.println("Nhập ngày đi được: ");
			long checkNgayDiDuoc = 0;
			int ngayDiDuoc = (int) nhapSo(checkNgayDiDuoc, "ngày đi được");
			ChuyenXeNgoaiThanh cxngt = new ChuyenXeNgoaiThanh(maXe, hoTenTaiXe, soXe, doanhThu, noiDen, ngayDiDuoc);
			dsChuyenXe.addChuyenXe(cxngt);
		}else if(loaiXe == noiThanh) {
			System.out.println("Nhập số tuyến: ");
			String checkSoTuyen = null;
			String soTuyen = nhapChuoi(checkSoTuyen, "số tuyến");
			System.out.println("Nhập số km đi được: ");
			long checkKmDiDuoc = 0;
			double kmDiDuoc = (double) nhapSo(checkKmDiDuoc, "số km đi được");
			ChuyenXeNoiThanh cxnt = new ChuyenXeNoiThanh(maXe, hoTenTaiXe, soXe, doanhThu, soTuyen, kmDiDuoc);
			dsChuyenXe.addChuyenXe(cxnt);
		}
		System.out.println("Thêm mới thành công chuyến xe: "+maXe);
		
	}

	private static void menuChuyenXe(DanhSachChuyenXe dsChuyenXe) {
		int chon;
		do {
			tieuDeMenuChuyenXe();
			System.out.println("Bạn chọn số? ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 4) {
				System.out.println("Chọn sai! ");
				tieuDeMenuChuyenXe();
				System.out.println("Chọn lại từ (1 đến 4): ");
			}else {
				switch (chon) {
				case 1:
					nhapCungChuyenXe(dsChuyenXe);
					break;
				case 2:
					menuChonNhapChuyenXe(dsChuyenXe);
					break;
				case 3:
					xuatDanhSach(dsChuyenXe);
					xuatDoanhThu(dsChuyenXe);
					break;
		
				default:
					break;
				}
			}
		}while(chon != 4);
	}


	//validate
	//Nhập mềm
	public static long nhapSo(long number, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				number = sc.nextLong();
			} catch (Exception e) {
				System.out.println(title+ "bạn vừa nhập không phải số");
				throw null;
			}
			if(number < 0) {
				System.out.println(title+" - Không được bé hơn 0!\nNhập lại:");
			}
		}while(number < 0);
		return number;
	}

	public static String nhapChuoi(String str, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				str = sc.nextLine();
			} catch (Exception e) {
				System.out.println("Something wrong!!");
				throw null;
			}
			if(str == null || str.isEmpty()) {
				System.out.println(title+" - Không được để trống!\nNhập lại:");
			}
		}while(str == null || str.isEmpty());

		return str;
	}
	
}
