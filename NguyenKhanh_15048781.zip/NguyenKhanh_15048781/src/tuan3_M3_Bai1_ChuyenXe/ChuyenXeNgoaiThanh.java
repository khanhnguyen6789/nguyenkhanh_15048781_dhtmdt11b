package tuan3_M3_Bai1_ChuyenXe;

public class ChuyenXeNgoaiThanh extends ChuyenXe{
	private String noiDen;
	private int ngayDiDuoc;
	public String getNoiDen() {
		return noiDen;
	}
	public void setNoiDen(String noiDen) {
		this.noiDen = noiDen;
	}
	public int getNgayDiDuoc() {
		return ngayDiDuoc;
	}
	public void setNgayDiDuoc(int ngayDiDuoc) {
		this.ngayDiDuoc = ngayDiDuoc;
	}
	public ChuyenXeNgoaiThanh(String maXe, String hoTenTaiXe, String soXe, double doanhThu, String noiDen,
			int ngayDiDuoc) {
		super(maXe, hoTenTaiXe, soXe, doanhThu);
		this.noiDen = noiDen;
		this.ngayDiDuoc = ngayDiDuoc;
	}
	public ChuyenXeNgoaiThanh() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ChuyenXeNgoaiThanh(String maXe, String hoTenTaiXe, String soXe, double doanhThu) {
		super(maXe, hoTenTaiXe, soXe, doanhThu);
		// TODO Auto-generated constructor stub
	}
	public ChuyenXeNgoaiThanh(String maXe, String hoTenTaiXe, String soXe) {
		super(maXe, hoTenTaiXe, soXe);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String stringNgoaiThanh = String.format(" | %-22s | %-15s | %-15s | %-20s | %20d ","Chuyến Xe ngoại thành","","", this.getNoiDen(), this.getNgayDiDuoc());
		return super.toString()+stringNgoaiThanh;
//		return "Chuyến xe ngoại thành\n"+super.toString()+" nơi đến: "+this.getNoiDen()+" Số ngày đi được: "+this.getNgayDiDuoc();
	}
	
}
