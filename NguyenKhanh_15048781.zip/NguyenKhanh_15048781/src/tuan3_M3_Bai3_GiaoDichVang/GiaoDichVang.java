package tuan3_M3_Bai3_GiaoDichVang;

import java.text.DecimalFormat;
import java.util.GregorianCalendar;

public class GiaoDichVang extends GiaoDich {
	private String loaiVang;

	public String getLoaiVang() {
		return loaiVang;
	}

	public void setLoaiVang(String loaiVang) {
		this.loaiVang = loaiVang;
	}

	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param soLuong
	 * @param loaiVang
	 */
	public GiaoDichVang(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, int soLuong,
			String loaiVang) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong);
		this.loaiVang = loaiVang;
	}

	public GiaoDichVang() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param soLuong
	 */
	public GiaoDichVang(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, int soLuong) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong);
		// TODO Auto-generated constructor stub
	}
	public double thanhTien() {
		double tongTien = 0;
		tongTien = this.getSoLuong() * this.getDonGia();
		return tongTien;
	}
	
	@Override
	public String toString() {
		DecimalFormat fm = new DecimalFormat("###,000");
		//										loaivang tygia	loaitien
		String toStringGDVang = String.format(" | %15s | %15s | %15s | %20s | %25s", this.loaiVang, "--","--","Giao dịch vàng",fm.format(this.thanhTien()));
		return super.toString()+ toStringGDVang;
	}
}
