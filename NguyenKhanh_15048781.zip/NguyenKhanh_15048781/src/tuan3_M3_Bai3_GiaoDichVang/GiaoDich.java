package tuan3_M3_Bai3_GiaoDichVang;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public abstract class GiaoDich {
	protected String maGiaoDich;
	protected GregorianCalendar ngayGiaoDich;
	protected double donGia;
	protected int soLuong;
	protected abstract double thanhTien();

	public String getMaGiaoDich() {
		return maGiaoDich;
	}
	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}
	public GregorianCalendar getNgayGiaoDich() {
		return ngayGiaoDich;
	}
	public void setNgayGiaoDich(GregorianCalendar ngayGiaoDich) {
		this.ngayGiaoDich = ngayGiaoDich;
	}
	public double getDonGia() {
		return donGia;
	}
	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param soLuong
	 */
	public GiaoDich(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, int soLuong) {
		super();
		this.maGiaoDich = maGiaoDich;
		this.ngayGiaoDich = ngayGiaoDich;
		this.donGia = donGia;
		this.soLuong = soLuong;
	}
	/**
	 * 
	 */
	public GiaoDich() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maGiaoDich == null) ? 0 : maGiaoDich.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GiaoDich other = (GiaoDich) obj;
		if (maGiaoDich == null) {
			if (other.maGiaoDich != null)
				return false;
		} else if (!maGiaoDich.equals(other.maGiaoDich))
			return false;
		return true;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		DecimalFormat fm = new DecimalFormat("###,000");
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		//					MAgd	dongia	soluong ngày
		return String.format("%-15s | %20s | %10d | %15s", this.getMaGiaoDich(), fm.format(this.getDonGia()), this.getSoLuong(), fd.format(this.getNgayGiaoDich().getTime()));
	}
	
}
