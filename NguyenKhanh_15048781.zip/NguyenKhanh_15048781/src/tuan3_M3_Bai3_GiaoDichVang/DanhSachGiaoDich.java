package tuan3_M3_Bai3_GiaoDichVang;

import java.text.DecimalFormat;
import java.util.ArrayList;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DanhSachGiaoDich {
	List<GiaoDich> dsGiaoDich = new ArrayList<GiaoDich>();

	public boolean themGiaoDich(GiaoDich giaoDich) {
		if(dsGiaoDich.contains(giaoDich)) {
			return false;
		}else {
			dsGiaoDich.add(giaoDich);
			return true;
		}

	}

	public int tongSoLuongVang() {
		int tong = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichVang) {
				tong+=giaoDich.getSoLuong();
			}
		}
		return tong;
	}

	public int tongSoLuongTienTe() {
		int tong = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichTienTe) {
				tong+=giaoDich.getSoLuong();
			}
		}
		return tong;
	}

	public String trungBinhGiaoDichTienTe() {
		double tong = 0;
		DecimalFormat fm = new DecimalFormat("###,000");
		int soRecord = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichTienTe) {
				soRecord++;
				tong = (tong + giaoDich.thanhTien());
			}
		}
		return fm.format(tong/soRecord);
	}

	public void sapXeGiaoDich() {
		Collections.sort(dsGiaoDich, new Comparator<GiaoDich>() {

			@Override
			public int compare(GiaoDich o1, GiaoDich o2) {
				Integer sapXepID = o1.getMaGiaoDich().compareTo(o2.getMaGiaoDich());
				return sapXepID;
			}
		});
	}

	public List<GiaoDich> layGiaoDichLonHon1Ty() {
		List<GiaoDich> listTam = new ArrayList<GiaoDich>();
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich.getDonGia() > 1E9) {
				listTam.add(giaoDich);
			}
		}
		return listTam;
	}
	
	public List<GiaoDich> getAll() {
		return dsGiaoDich;
	}
}
