package tuan3_M3_Bai3_GiaoDichVang;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.GregorianCalendar;

import java.util.Scanner;

public class testGiaoDich {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {

		DanhSachGiaoDich dsGiaoDich = new DanhSachGiaoDich();
		try {
			menuGiaoDich(dsGiaoDich);
			//				menuGiaoDich(dsGiaoDich);
		} catch (Exception e) {
			System.out.println("Lỗi chương trình!! Chương trình dừng lại,");
		}

	}

	public static void nhapCungGiaoDich(DanhSachGiaoDich dsGiaoDich) {

		GregorianCalendar ngayGD1 = new GregorianCalendar(2020,12-1,20);
		GregorianCalendar ngayGD2 = new GregorianCalendar(2020,05-1,10);
		GiaoDich giaoDich1 = new GiaoDichVang("2", ngayGD1, 20000, 10, "Cục");
		GiaoDich giaoDich2 = new GiaoDichVang("5", ngayGD2, 30000, 11, "Đặc");
		GiaoDich giaoDich3 = new GiaoDichVang("4", ngayGD1, 40000, 12, "Trắng");
		GiaoDich giaoDich4 = new GiaoDichVang("1", ngayGD2, 1100000000, 1, "Bạch Kim");
		GiaoDich giaoDich5 = new GiaoDichVang("3", ngayGD1, 2000000000, 1, "Thẻ");

		GiaoDichTienTe giaoDich6 = new GiaoDichTienTe("6", ngayGD2, 1100000000, 1, 275000, 2);
		GiaoDichTienTe giaoDich7 = new GiaoDichTienTe("7", ngayGD2, 2100000000, 1, 375000, 3);
		GiaoDichTienTe giaoDich8 = new GiaoDichTienTe("8", ngayGD2, 80000, 1, 175000, 1);
		dsGiaoDich.themGiaoDich(giaoDich1);
		dsGiaoDich.themGiaoDich(giaoDich2);
		dsGiaoDich.themGiaoDich(giaoDich3);
		dsGiaoDich.themGiaoDich(giaoDich4);
		dsGiaoDich.themGiaoDich(giaoDich5);
		dsGiaoDich.themGiaoDich(giaoDich6);
		dsGiaoDich.themGiaoDich(giaoDich7);
		dsGiaoDich.themGiaoDich(giaoDich8);
	}
	public static void tieuDe() {
		//								MAgd	dongia	soluong ngày loaivang tygia loaitien
		System.out.println(String.format("%-15s | %20s | %10s | %15s | %15s | %15s | %15s | %20s | %25s", "Mã giao dịch", "Đơn Giá", "Số lượng", "Ngày giao dịch","Loại Vàng","Tỷ Giá","Loại Tiền","Loại Giao Dịch","Thành Tiền"));
	}

	public static void xuatGiaoDichLonHon1Ty(DanhSachGiaoDich dsGiaoDich) {
		System.out.println("\t\t\t\t"+"Danh Sách Đơn Giá Lớn Hơn 1 Tỷ".toUpperCase());
		tieuDe();
		for(GiaoDich giaoDich : dsGiaoDich.layGiaoDichLonHon1Ty()) {
				System.out.println(giaoDich);
		}
		System.out.println("\n");
	}

	public static void xuatDanhSach(DanhSachGiaoDich dsGiaoDich) {
		System.out.println("\t\t\t\tDANH SÁCH GIAO DỊCH");
		tieuDe();
		dsGiaoDich.sapXeGiaoDich();
		for(GiaoDich giaoDich : dsGiaoDich.getAll()) {
			System.out.println(giaoDich);
		}
		System.out.println("Tổng số lượng giao dịch Vàng: "+dsGiaoDich.tongSoLuongVang());
		System.out.println("Tổng số lượng giao dịch Tiền Tệ: "+dsGiaoDich.tongSoLuongTienTe());
		System.out.println("Trung bình thành tiền của giao dịch tiền tệ: " + dsGiaoDich.trungBinhGiaoDichTienTe());
		System.out.println("\n");
	}

	public static void chonGiaoDichNhapMem(DanhSachGiaoDich dsGiaoDich) {

		int chon = 0;
		do {
			System.out.println("===\t CHỌN LOẠI GIAO DỊCH \t===");
			System.out.println("1. Giao Dịch Vàng.");
			System.out.println("2. Giao Dịch Tiền Tệ.");
			System.out.println("3. Trở lại.");
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			switch (chon) {
			case 1://Vàng option 1
				int optionVang = 1;
				nhapMemGiaoDich(dsGiaoDich,optionVang);

				chon = 3;
				break;
			case 2://Tiền tệ option 2
				int optionTienTe = 2;
				nhapMemGiaoDich(dsGiaoDich,optionTienTe);

				chon = 3;
				//				dsGiaoDich.themGiaoDich(giaoDichTienTe);
				break;

			case 3:
				break;
			default:
				break;
			}
			if(chon > 3 || chon < 0) {
				System.out.println("Chọn sai!! Chọn lại: ");
			}
		}while(chon != 3);

	}

	public static void nhapMemGiaoDich(DanhSachGiaoDich dsGiaoDich,int loaiGiaoDich) {
		sc.nextLine();
		int giaoDichVang = 1, giaoDichTienTe = 2;
		//		GiaoDichVang giaoDich = new GiaoDichVang();
		GregorianCalendar ngayGiaoDich = new GregorianCalendar();
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		//mã String
		System.out.println("Nhập mã Giao Dịch: ");
		String checkMaGiaoDich = null;
		String maGiaoDich = nhapChuoi(checkMaGiaoDich, "mã giao dịch");

		//Ngày String format từ GregorianCalendar
		System.out.println("Nhập ngày Giao Dịch ('dd/mm/yyyy'): ");
		String checktxtNgayGiaoDich = null;
		String textNgayGiaoDich = nhapChuoi(checktxtNgayGiaoDich, "ngày giao dịch");
		try {
			ngayGiaoDich.setTime(fd.parse(textNgayGiaoDich));
		} catch (ParseException e) {
			e.printStackTrace();
			System.out.println("SomeThing wrong!!");throw null;
		}

		//Đơn giá double
		System.out.println("Nhập đơn giá: ");
		long checkDonGia = 0;
		double donGia = (double) nhapSo(checkDonGia, "đơn giá");

		//Số lượng int
		System.out.println("Nhập số lượng: ");
		long checkSoLuong = 0;
		int soLuong = (int) nhapSo(checkSoLuong, "số lượng");

		if(loaiGiaoDich == giaoDichVang) {
			sc.nextLine();
			//loại vàng String
			System.out.println("Nhập loại vàng: ");
			String checkLoaiVang = null;
			String loaiVang = nhapChuoi(checkLoaiVang, "loại vàng");
			
			GiaoDichVang giaoDichVangMoi = new GiaoDichVang(maGiaoDich, ngayGiaoDich, donGia, soLuong, loaiVang);
			dsGiaoDich.themGiaoDich(giaoDichVangMoi);
		}
		else if (loaiGiaoDich == giaoDichTienTe) {
			System.out.println("Nhập tỷ giá: ");
			long checkTygia = 0;
			double tyGia = (double) nhapSo(checkTygia, "tỷ giá");
			
			System.out.println("Chọn loại tiền: ");
			int loaiTienTe = chonLoaiTienTe();
			
			GiaoDichTienTe giaoDichTienMoi = new GiaoDichTienTe(maGiaoDich, ngayGiaoDich, donGia, soLuong, tyGia, loaiTienTe);
			dsGiaoDich.themGiaoDich(giaoDichTienMoi);
		} 
		
		System.out.println("Thêm mới giao dịch: "+maGiaoDich+" - Thành công!");

	}

	public static int chonLoaiTienTe() {
		int chonChange = 0;
		int loaiTienTe = -1;
		do {
			System.out.println("1. Việt Nam.");
			System.out.println("2. Usd.");
			System.out.println("3. Euro.");
			System.out.println("Chọn số?: ");
			chonChange = sc.nextInt();

			if(chonChange < 0 || chonChange > 3) {
				System.out.println("Chọn sai!! Vui lòng chọn lại từ (1 đến 3): ");
			}else {
				switch (chonChange) {
				case 1:
					//Việt Nam
					loaiTienTe = 1;
					chonChange = 4;
					break;

				case 2:
					//USD và Euro cùng kiểu
					loaiTienTe = 2;
					chonChange = 4;
					break;

				case 3:
					//USD và Euro cùng kiểu
					loaiTienTe = 3;
					chonChange = 4;
					break;

				default:
					break;
				}
			}
		}while(chonChange != 4);

		return loaiTienTe;
	}

	public static void menuGiaoDich(DanhSachGiaoDich dsGiaoDich) {

		int chon = 0;

		do {

			System.out.println("=== MENU GIAO DỊCH ===");
			System.out.println("0. Nhập cứng giao dịch.");
			System.out.println("1. Nhập 1 giao dịch.");
			System.out.println("2. Xuất Danh Sách Giao Dịch.");
			System.out.println("3. Xuất các giao dịch lớn hơn hoặc bằng 1 tỷ.");
			System.out.println("4.Thoát.");
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 4) {
				System.out.println("Chọn sai(số từ 1-4)!! Chọn lại: ");
			}else {
				switch (chon) {
				case 0:
					nhapCungGiaoDich(dsGiaoDich);
					break;
				case 1:
					chonGiaoDichNhapMem(dsGiaoDich);

					break;
				case 2:
					xuatDanhSach(dsGiaoDich);
					break;
				case 3:
					xuatGiaoDichLonHon1Ty(dsGiaoDich);

					break;
				case 4:

					break;

				default:
					break;
				}
			}

		}while( chon != 4);

	}


	//input
	public static long nhapSo(long number, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				number = sc.nextLong();
			} catch (Exception e) {
				System.out.println(title+ "bạn vừa nhập không phải số");
				throw null;
			}
			if(number < 0) {
				System.out.println(title+" - Không được bé hơn 0!\nNhập lại:");
			}
		}while(number < 0);
		return number;
	}

	public static String nhapChuoi(String str, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				str = sc.nextLine();
			} catch (Exception e) {
				System.out.println("Something wrong!!");
				throw null;
			}
			if(str == null || str.isEmpty()) {
				System.out.println(title+" - Không được để trống!\nNhập lại:");
			}
		}while(str == null || str.isEmpty());

		return str;
	}
	//end input

}


