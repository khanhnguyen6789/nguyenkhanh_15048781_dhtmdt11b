package tuan3_M3_Bai3_GiaoDichVang;

import java.text.DecimalFormat;
import java.util.GregorianCalendar;

public class GiaoDichTienTe extends GiaoDich{
	private double tyGia;
	protected int loaiTien;//1: VN, 2:USD, 3: Euro;
	public double getTyGia() {
		return tyGia;
	}
	public void setTyGia(double tyGia) {
		this.tyGia = tyGia;
	}
	public int getLoaiTien() {
		return loaiTien;
	}
	public void setLoaiTien(int loaiTien) {
		this.loaiTien = loaiTien;
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param soLuong
	 * @param tyGia
	 * @param loaiTien
	 */
	public GiaoDichTienTe(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, int soLuong, double tyGia,
			int loaiTien) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong);
		this.tyGia = tyGia;
		this.loaiTien = loaiTien;
	}
	/**
	 * 
	 */
	public GiaoDichTienTe() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param soLuong
	 */
	public GiaoDichTienTe(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, int soLuong) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong);
		// TODO Auto-generated constructor stub
	}

	public String kiemTraTien(int tienTe) {
		
		if(tienTe == 1) {
			return "VN";
		}else if(tienTe == 2) {
			return "USD";
		}else {
			return "Euro";
		}
	}

	public double thanhTien() {
		double tongTien = 0;
		String checkTien = this.kiemTraTien(this.getLoaiTien());
		if(checkTien.toUpperCase().equals("VN")) {
			tongTien = this.getSoLuong() * this.getDonGia();
		}else {//USD or Euro
			tongTien = this.getSoLuong() * this.getDonGia() * this.getTyGia();
		}
		return tongTien;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		DecimalFormat fm = new DecimalFormat("###,000");
		String toStringGDTien = String.format(" | %15s | %15s | %15s | %20s | %25s", "--", fm.format(this.getTyGia()),this.kiemTraTien(this.getLoaiTien()),"Giao dịch tiền tệ",fm.format(this.thanhTien()));
		return super.toString()+ toStringGDTien;
	}
}
