package tuan3_M3_Bai2_QuanLySach;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Scanner;


public class testSach {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//		SimpleDateFormat fm = new SimpleDateFormat("dd/MM/yyyy");

		QuanLySach dsSach = new QuanLySach();
		try {
			menuQuanLySach(dsSach);
		} catch (Exception e) {
			System.out.println("Lỗi chương trình!! Chương trình dừng lại,");

		}

	}
	public static void tieuDe() {
		//											mã	dongia	sl		ngay	nxb	 tinhtrang	thuế
		System.out.println(String.format("%15s | %20s | %10s | %-12s | %-20s | %-12s | %-10s | %-15s", "Mã sách","Đơn giá","Số lượng","Ngày nhập","Nhà xuất bản","Tình trạng","Thuế","Loại Sách"));
	}

	private static void tieuDeMenuSach() {
		System.out.println("MENU QUẢN LÝ SÁCH");
		System.out.println("1. Nhập cứng Sách.");
		System.out.println("2. Nhập mới một Sách.");
		System.out.println("3. Xuất Danh sách Sách.");
		System.out.println("4. Tìm sách theo tên Nhà Xuất Bản.");
		System.out.println("5. Thoát.");
	}

	private static void tieuDeChonNhapSach() {
		System.out.println("CHỌN PHƯƠNG THỨC NHẬP SÁCH");
		System.out.println("1. Nhập một Sách Giáo Khoa.");
		System.out.println("2. Nhập một Sách Tham Khảo.");
		System.out.println("3. Thoát.");
	}

	private static void menuQuanLySach(QuanLySach dsSach) {
		int chon;
		do {
			tieuDeMenuSach();
			System.out.println("Bạn chọn số? ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 5) {
				System.out.println("Chọn sai! ");
				tieuDeMenuSach();
				System.out.println("Chọn lại từ (1 đến 5): ");
			}else {
				switch (chon) {
				case 1:
					nhapCungSach(dsSach);
					break;
				case 2:
					menuChonNhapSach(dsSach);
					break;
				case 3:
					xuatDanhSach(dsSach);
					tongTienLoaiSach(dsSach);
					break;
				case 4:
					sc.nextLine();
					System.out.println("Nhập tên nhà xuất bản muốn xuất");
					String maNhaXuatBanTim = sc.nextLine();
					
					xuatDanhSachTheoNhaXuatBan(dsSach,maNhaXuatBanTim);
					break;
				default:
					break;
				}
			}
		}while(chon != 5);
	}

	private static void menuChonNhapSach(QuanLySach dsSach) {
		int chon;
		do {
			tieuDeChonNhapSach();
			System.out.println("Bạn chọn số? ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 3) {
				System.out.println("Chọn sai! ");
				tieuDeChonNhapSach();
				System.out.println("Chọn lại từ (1 đến 3): ");
			}else {
				switch (chon) {
				case 1:
					System.out.println("NHẬP SÁCH GIÁO KHOA\n");
					int sachGiaoKhoa = 1;
					sc.nextLine();
					nhapMemSach(dsSach,sachGiaoKhoa);
					chon = 3;
					break;
				case 2:
					System.out.println("NHẬP SÁCH THAM KHẢO\n");
					int sachThamKhao = 2;
					sc.nextLine();
					nhapMemSach(dsSach,sachThamKhao);
					chon = 3;
					break;
				default:
					break;
				}
			}
		}while(chon != 3);
	}

	public static void nhapCungSach(QuanLySach dsSach) {
		GregorianCalendar ngayNhap1 = new GregorianCalendar(2020,12-1,23);
		GregorianCalendar ngayNhap2 = new GregorianCalendar(2019,02-1,25);
		Sach sach1= new SachGiaoKhoa("1", "Kim Đồng", ngayNhap1, 50000, 1,1);
		Sach sach2= new SachGiaoKhoa("2", "Kim Đồng", ngayNhap1, 50000, 1,1);
		Sach sach3= new SachGiaoKhoa("3", "Kim Đồng", ngayNhap1, 50000, 1,0);
		Sach sach4= new SachGiaoKhoa("4", "Kim Đồng", ngayNhap1, 50000, 2,0);
		Sach sach5= new SachGiaoKhoa("5", "Kim Đồng", ngayNhap1, 50000, 3,0);
		Sach sach6= new SachGiaoKhoa("6", "khoa hoc", ngayNhap1, 50000, 1,1);
		Sach sach7= new SachGiaoKhoa("7", "khoa hoc", ngayNhap1, 50000, 1,0);
		Sach sach9= new SachGiaoKhoa("8", "Viễn tưởng", ngayNhap1, 700000, 1, 1);

		Sach sach8 = new SachThamKhao("9", "Giáo dục", ngayNhap2, 50000, 1,10);
		Sach sach10 = new SachThamKhao("10", "Giáo dục", ngayNhap2, 50000, 1,10);
		Sach sach11 = new SachThamKhao("11", "Giáo dục", ngayNhap2, 50000, 1,10);
		Sach sach12 = new SachThamKhao("12", "Giáo dục", ngayNhap2, 50000, 1,10);


		dsSach.addSach(sach1);
		dsSach.addSach(sach2);
		dsSach.addSach(sach3);
		dsSach.addSach(sach4);
		dsSach.addSach(sach5);
		dsSach.addSach(sach6);
		dsSach.addSach(sach7);
		dsSach.addSach(sach8);
		dsSach.addSach(sach9);
		dsSach.addSach(sach10);
		dsSach.addSach(sach11);
		dsSach.addSach(sach12);

		xuatDanhSach(dsSach);
	}

	private static void nhapMemSach(QuanLySach dsSach, int loaiSach) {
		int sachGiaoKhoa = 1,sachThamKhao = 2;
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Nhập mã sách: ");
		String checkMaSach = null;
		String maSach= nhapChuoi(checkMaSach, "ngày");
		System.out.println("Nhập số lượng: ");
		long checkSoLuong = 0;
		int soLuong = (int) nhapSo(checkSoLuong, "số lượng");
		System.out.println("Nhập đơn giá: ");
		long checkDonGia = 0;
		double donGia = (double) nhapSo(checkDonGia, "đơn giá");
		sc.nextLine();
		System.out.println("Nhập ngày nhập sách(dd/mm/yyyy): ");
		String checkNgay = null;
		String ngayNhap= nhapChuoi(checkNgay, "ngày nhập sách");

		System.out.println("Nhập nhà xuất bản: ");
		String checkNhaXuatBan = null;
		String nhaXuatBan= nhapChuoi(checkNhaXuatBan, "nhà xuất bản");

		GregorianCalendar ngayNhapSach = new GregorianCalendar();
		try {
			ngayNhapSach.setTime(fd.parse(ngayNhap));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("SomeThing wrong!!");
			throw null;
		}

		if(loaiSach == sachGiaoKhoa) {
			System.out.println("Chọn tình trạng sách: ");
			int tinhTrangSach = menuTinhTrang(dsSach);
			
			SachGiaoKhoa sachGK = new SachGiaoKhoa(maSach, nhaXuatBan, ngayNhapSach, donGia, soLuong, tinhTrangSach);
			dsSach.addSach(sachGK);
		}else if(loaiSach == sachThamKhao) {
			System.out.println("Nhập số thuế: ");
			long checkThue = 0;
			double thue = 0;
			do {
				thue = (double) nhapSo(checkThue, "số thuế");
				if(thue > 100) {
					System.out.println("Thuế nhập từ (0 - 100) %\nNhập lại: ");
				}
			}while(thue > 100);
			SachThamKhao sachTK = new SachThamKhao(maSach, nhaXuatBan, ngayNhapSach, donGia, soLuong, thue);
			dsSach.addSach(sachTK);
		}
		System.out.println("Thêm mới thành công sách: "+maSach);

	}

	private static int menuTinhTrang(QuanLySach dsSach) {
		int chon;
		int tinhTrangSach = -1;
		do {
			System.out.println("1. Mới.");
			System.out.println("2. Cũ.");
			System.out.println("Bạn chọn số? ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 2) {
				System.out.println("Chọn sai! ");
				tieuDeMenuSach();
				System.out.println("Chọn lại từ (1 đến 2): ");
			}else {
				switch (chon) {
				case 1:
					
					tinhTrangSach = 1;// mới
					chon = 1239;
					break;
				case 2:
					
					tinhTrangSach = 0; // cũ
					chon = 1239;
					break;
				default:
					break;
				}
			}
		}while(chon != 1239);

		return tinhTrangSach;
	}

	public static void xuatDanhSachTheoNhaXuatBan(QuanLySach dsSach, String nhaXuatBan) {
		int count = dsSach.timTheoNhaXuatBan(nhaXuatBan).size();
		if(count != 0) {
			System.out.println("\t\t\t\tDANH SÁCH SÁCH CỦA NHÀ XUẤT BẢN "+ nhaXuatBan.toUpperCase());
			tieuDe();
			for(Sach row: dsSach.timTheoNhaXuatBan(nhaXuatBan)) {
				System.out.println(row);
			}
			System.out.println("\n");
		}else {
			System.out.println("Không có sách nào với nhà xuất bản "+nhaXuatBan);
		}

	}

	public static void xuatDanhSach(QuanLySach dsSach) {
		System.out.println("\t\t\t\tDANH SÁCH QUẢN LÝ SÁCH");
		tieuDe();
		dsSach.sapXep();
		for(Sach row: dsSach.getAll()) {
			System.out.println(row);
		}
		System.out.println("\n");
		tongTienLoaiSach(dsSach);
	}

	public static void tongTienLoaiSach(QuanLySach dsSach) {
		System.out.println("Trung bình đơn giá sách tham khảo là: " + dsSach.tinhTBSachThamKhao());
		System.out.println("Tổng tiền sách giáo khoa: "+dsSach.tinhTongTienSachGiaoKhoa());
		System.out.println("Tổng tiền sách giáo khoa: "+dsSach.tinhTongTienSachThamKhao());

		System.out.println("\n");
	}

	//input
	public static long nhapSo(long number, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				number = sc.nextLong();
			} catch (Exception e) {
				System.out.println(title+ "bạn vừa nhập không phải số");
				throw null;
			}
			if(number < 0) {
				System.out.println(title+" - Không được bé hơn 0!\nNhập lại:");
			}
		}while(number < 0);
		return number;
	}

	public static String nhapChuoi(String str, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				str = sc.nextLine();
			} catch (Exception e) {
				System.out.println("Something wrong!!");
				throw null;
			}
			if(str == null || str.isEmpty()) {
				System.out.println(title+" - Không được để trống!\nNhập lại:");
			}
		}while(str == null || str.isEmpty());

		return str;
	}
	//end input
}
