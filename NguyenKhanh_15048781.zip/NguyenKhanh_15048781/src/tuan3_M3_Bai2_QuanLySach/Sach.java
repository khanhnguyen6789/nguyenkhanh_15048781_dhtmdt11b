package tuan3_M3_Bai2_QuanLySach;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Sach {
	protected String maSach, nhaXuatBan;
	protected GregorianCalendar ngayNhap;
	protected double donGia;
	protected int soLuong;
	public String getMaSach() {
		return maSach;
	}
	public void setMaSach(String maSach) {
		this.maSach = maSach;
	}
	public String getNhaXuatBan() {
		return nhaXuatBan;
	}
	public void setNhaXuatBan(String nhaXuatBan) {
		this.nhaXuatBan = nhaXuatBan;
	}
	public GregorianCalendar getNgayNhap() {
		return ngayNhap;
	}
	public void setNgayNhap(GregorianCalendar ngayNhap) {
		this.ngayNhap = ngayNhap;
	}
	public double getDonGia() {
		return donGia;
	}
	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	
	
	/**
	 * @param maSach
	 * @param nhaXuatBan
	 * @param ngayNhap
	 * @param donGia
	 * @param soLuong
	 */
	public Sach(String maSach, String nhaXuatBan, GregorianCalendar ngayNhap, double donGia, int soLuong) {
		super();
		this.maSach = maSach;
		this.nhaXuatBan = nhaXuatBan;
		this.ngayNhap = ngayNhap;
		this.donGia = donGia;
		this.soLuong = soLuong;
	}
	
	public Sach() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maSach == null) ? 0 : maSach.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sach other = (Sach) obj;
		if (maSach == null) {
			if (other.maSach != null)
				return false;
		} else if (!maSach.equals(other.maSach))
			return false;
		return true;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		DecimalFormat fm = new DecimalFormat("###,000");
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		//						mã	dongia	sl		ngay	nxb
		return String.format("%15s | %20s | %10d | %-12s | %-20s", this.getMaSach(), fm.format(this.getDonGia()), this.getSoLuong() , fd.format(this.getNgayNhap().getTime().getTime()), this.getNhaXuatBan());
	}
}
