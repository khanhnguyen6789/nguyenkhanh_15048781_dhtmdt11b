package tuan3_M3_Bai2_QuanLySach;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class QuanLySach {
	List<Sach> dsSach = new ArrayList<Sach>();
	public boolean addSach(Sach sach) {
		if(dsSach.contains(sach)) {
			return false;
		}else {
			dsSach.add(sach);
			return true;
		}
	}
	
	public Sach timSach(String maSach) {
		
		for(Sach row : dsSach) {
			if(row.getMaSach().toLowerCase().equalsIgnoreCase(maSach.toLowerCase())) {
				return dsSach.get(dsSach.indexOf(row));
			}
		}
		return null;
	}
	
	public String tinhTongTienSachGiaoKhoa() {
		DecimalFormat fm = new DecimalFormat("###,000");
		double tongTien = 0;
		for(Sach row : dsSach) {
			if(row instanceof SachGiaoKhoa) {
				tongTien += ((SachGiaoKhoa) row).tinhTien();
			}
		}
		return fm.format(tongTien);
	}
	
	public String tinhTongTienSachThamKhao() {
		DecimalFormat fm = new DecimalFormat("###,000");
		double tongTien = 0;
		for(Sach row : dsSach) {
			if(row instanceof SachThamKhao) {
				tongTien += ((SachThamKhao) row).tinhTien();
			}
		}
		return fm.format(tongTien);
	}
	
	public String tinhTBSachThamKhao() {
		DecimalFormat fm = new DecimalFormat("###,000");
		double tongTien = 0;
		for(Sach row : dsSach) {
			if(row instanceof SachThamKhao) {
				tongTien += row.getDonGia();
			}
		}
		return fm.format(tongTien);
	}
	
	public void sapXep() {
		Collections.sort(dsSach, new Comparator<Sach>() {

			@Override
			public int compare(Sach o1, Sach o2) {
				// TODO Auto-generated method stub
				return o1.getMaSach().compareToIgnoreCase(o2.getMaSach());
			}
		});
	}
	public List<Sach> timTheoNhaXuatBan(String nhaXuatBan){
		List<Sach> sachNhaXuatBan = new ArrayList<Sach>();
		for(Sach row : dsSach) {
			if(row.getNhaXuatBan().toLowerCase().equalsIgnoreCase(nhaXuatBan.toLowerCase())) {
				sachNhaXuatBan.add(row);
			}
		}
		return sachNhaXuatBan;
	}
	
	public List<Sach> getAll() {
		return dsSach;
	}
	
}
