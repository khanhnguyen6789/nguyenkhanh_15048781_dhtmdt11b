package tuan3_M3_Bai2_QuanLySach;


import java.util.GregorianCalendar;

public class SachThamKhao extends Sach {
	private double thue;

	public double getThue() {
		return thue;
	}

	public void setThue(double thue) {
		this.thue = thue;
	}

	/**
	 * @param maSach
	 * @param nhaXuatBan
	 * @param ngayNhap
	 * @param donGia
	 * @param soLuong
	 * @param thue
	 */
	public SachThamKhao(String maSach, String nhaXuatBan, GregorianCalendar ngayNhap, double donGia, int soLuong,
			double thue) {
		super(maSach, nhaXuatBan, ngayNhap, donGia, soLuong);
		this.thue = thue;
	}

	/**
	 * 
	 */
	public SachThamKhao() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param maSach
	 * @param nhaXuatBan
	 * @param ngayNhap
	 * @param donGia
	 * @param soLuong
	 */
	public SachThamKhao(String maSach, String nhaXuatBan, GregorianCalendar ngayNhap, double donGia, int soLuong) {
		super(maSach, nhaXuatBan, ngayNhap, donGia, soLuong);
		// TODO Auto-generated constructor stub
	}
	
	public double tinhTien() {
		double tienMoiSach = 0;
		tienMoiSach = (super.getSoLuong() * super.getDonGia()) + this.getThue();
		return tienMoiSach;
	}

	@Override
	public String toString() {
//		DecimalFormat df = new DecimalFormat("###,000");
		String sachThamKhao = String.format(" | %12s | %-10.0f | %-15s","--", this.getThue(),"Sách Tham Khảo");
		return super.toString() + sachThamKhao;
	}
}
