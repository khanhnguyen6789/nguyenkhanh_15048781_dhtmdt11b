package tuan3_M3_Bai2_QuanLySach;

import java.util.GregorianCalendar;

public class SachGiaoKhoa extends Sach {
	private int tinhTrang;

	public int getTinhTrang() {
		return tinhTrang;
	}

	public void setTinhTrang(int tinhTrang) {
		this.tinhTrang = tinhTrang;
	}

	/**
	 * @param maSach
	 * @param nhaXuatBan
	 * @param ngayNhap
	 * @param donGia
	 * @param soLuong
	 * @param tinhTrang
	 */
	public SachGiaoKhoa(String maSach, String nhaXuatBan, GregorianCalendar ngayNhap, double donGia, int soLuong,
			int tinhTrang) {
		super(maSach, nhaXuatBan, ngayNhap, donGia, soLuong);
		this.tinhTrang = tinhTrang;
	}

	/**
	 * 
	 */
	public SachGiaoKhoa() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param maSach
	 * @param nhaXuatBan
	 * @param ngayNhap
	 * @param donGia
	 * @param soLuong
	 */
	public SachGiaoKhoa(String maSach, String nhaXuatBan, GregorianCalendar ngayNhap, double donGia, int soLuong) {
		super(maSach, nhaXuatBan, ngayNhap, donGia, soLuong);
		// TODO Auto-generated constructor stub
	}

	public double tinhTien() {
		double tienMoiSach = 0;
//		(this.tinhTrang == 1) ? tienMoiSach = super.getSoLuong() * super.getDonGia() : tienMoiSach = super.getSoLuong() * super.getDonGia();
		if(this.tinhTrang == 1) {//mới
			tienMoiSach = super.getSoLuong() * super.getDonGia();
		}else {//cũ
			tienMoiSach = (super.getSoLuong() * super.getDonGia())*0.5;
		}
//		tienMoiSach = super.getSoLuong() * super.getDonGia() + this.getThue();
		return tienMoiSach;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String tinhTrangSachGiaoKhoa = (this.getTinhTrang() == 1) ? "Mới" : "Cũ";
//		String tinhTrangSachGiaoKhoa = "Mới";
		//										tinhtrang
		String sachGiaoKhoa = String.format(" | %-12s | %10s | %-15s", tinhTrangSachGiaoKhoa,"--","Sách Giáo Khoa");
		return super.toString() + sachGiaoKhoa;
	}

}
