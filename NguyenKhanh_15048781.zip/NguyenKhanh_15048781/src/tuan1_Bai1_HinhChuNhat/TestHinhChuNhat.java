package tuan1_Bai1_HinhChuNhat;

import java.util.Scanner;

public class TestHinhChuNhat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HinhChuNhat hcn1 = new HinhChuNhat(2, 3);
		
		tieuDe();
		System.out.println(hcn1);
		
		Scanner scan = new Scanner(System.in);
		HinhChuNhat hcn = new HinhChuNhat();
		System.out.println("Nhập chiều dài: ");
		hcn.setChieuDai(scan.nextFloat());
		System.out.println("Nhập chiều rộng: ");
		hcn.setChieuRong(scan.nextFloat());
		
		tieuDe();
		System.out.println(hcn);
		
	}

	private static void tieuDe() {
		System.out.println(String.format("%10s %10s %15s %15s", "Chiều dài", "Chiều rộng","Chu vi","Diện tích"));
	}
}
