package tuan1_Bai1_HinhChuNhat;

public class HinhChuNhat {
	float chieuDai,chieuRong;
	Double dienTich,chuVi;
	public float getChieuDai() {
		return chieuDai;
	}
	public void setChieuDai(float chieuDai) {
		this.chieuDai = chieuDai;
	}
	public float getChieuRong() {
		return chieuRong;
	}
	public void setChieuRong(float chieuRong) {
		this.chieuRong = chieuRong;
	}
	public HinhChuNhat(float chieuDai, float chieuRong) {
		super();
		this.chieuDai = chieuDai;
		this.chieuRong = chieuRong;
	}
	public HinhChuNhat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Double tinhDienTich() {
		Double s ;
		s = (double) (this.getChieuDai() * this.getChieuRong());
		return s;
	}
	public Double tinhChuVi() {
		Double cv ;
		cv = (double) (this.getChieuDai() + this.getChieuRong()) * 2;
		return cv;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%10.2f %10.2f %15.2f %15.2f", this.getChieuDai(),this.getChieuRong(),this.tinhChuVi(),this.tinhDienTich());
		
	}
}
