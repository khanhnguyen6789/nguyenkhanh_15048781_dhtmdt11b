package tuan4_M4_GiaoDichNhaDat;

import java.text.DecimalFormat;

import java.util.GregorianCalendar;

public class GiaoDichDat extends GiaoDich{
	String loaiDat;

	public String getLoaiDat() {
		return loaiDat;
	}

	public void setLoaiDat(String loaiDat) {
		this.loaiDat = loaiDat.toUpperCase();
	}

	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param dienTich
	 * @param loaiDat
	 */
	public GiaoDichDat(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, double dienTich,
			String loaiDat) {
		super(maGiaoDich, ngayGiaoDich, donGia, dienTich);
		this.loaiDat = loaiDat.toUpperCase();
	}

	/**
	 * 
	 */
	public GiaoDichDat() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param dienTich
	 */
	public GiaoDichDat(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, double dienTich) {
		super(maGiaoDich, ngayGiaoDich, donGia, dienTich);
	}
	@Override
	public double tinhThanhTien() {
		double thanhTien = 0;
		if(this.getLoaiDat().equalsIgnoreCase("a")) {
			thanhTien = this.getDienTich() * this.getDonGia() * 1.5;
		}else if(this.getLoaiDat().equalsIgnoreCase("b") == true || this.getLoaiDat().equalsIgnoreCase("c") == true) {
			thanhTien = this.getDienTich() * this.getDonGia();
		}
		return thanhTien;
	}
	
	@Override
	public String toString() {
		DecimalFormat fm = new DecimalFormat("###,000");

		return super.toString()+String.format(" | %-20s | %-15s | %-15s | %25s | %-200s","Giao Dịch Đất", this.getLoaiDat(),"--",fm.format(this.tinhThanhTien()),"--");
	}
}
