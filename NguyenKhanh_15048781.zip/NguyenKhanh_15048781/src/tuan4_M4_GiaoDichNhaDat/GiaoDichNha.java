package tuan4_M4_GiaoDichNhaDat;

import java.text.DecimalFormat;
import java.util.GregorianCalendar;

public class GiaoDichNha extends GiaoDich{
	int loaiNha;//1:cao cap // 0: thuong
	String diaChi;
	public String getLoaiNha() {
		String kieuLoai = null;
		if(this.loaiNha == 1) {
			kieuLoai = "Cao cấp";
		}else if (this.loaiNha == 0) {
			kieuLoai = "Thường";
		}
		return kieuLoai;
	}
	public void setLoaiNha(int loaiNha) {
		this.loaiNha = loaiNha;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param dienTich
	 * @param loaiNha
	 * @param diaChi
	 */
	public GiaoDichNha(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, double dienTich, int loaiNha,
			String diaChi) {
		super(maGiaoDich, ngayGiaoDich, donGia, dienTich);
		this.loaiNha = loaiNha;
		this.diaChi = diaChi;
	}
	/**
	 * 
	 */
	public GiaoDichNha() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param dienTich
	 */
	public GiaoDichNha(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, double dienTich) {
		super(maGiaoDich, ngayGiaoDich, donGia, dienTich);
		// TODO Auto-generated constructor stub
	}
	@Override
	public double tinhThanhTien() {
		double thanhTien = 0;
		if (this.loaiNha == 1) {//cao cấp
			thanhTien = this.getDienTich() * this.getDonGia();
		}else if (this.loaiNha == 0) {
			thanhTien = (this.getDienTich() * this.getDonGia()) + ((this.getDienTich() * this.getDonGia())* 0.9);
		}
		return thanhTien;
	}
	
	@Override
	public String toString() {
		DecimalFormat fm = new DecimalFormat("###,000");
		return super.toString()+String.format(" | %-20s | %-15s | %-15s | %25s | %-200s","Giao Dịch Nhà", "--",this.getLoaiNha(),fm.format(this.tinhThanhTien()),this.getDiaChi());
		
	}
}
