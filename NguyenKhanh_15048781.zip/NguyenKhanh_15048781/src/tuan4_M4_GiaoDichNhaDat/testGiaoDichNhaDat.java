package tuan4_M4_GiaoDichNhaDat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class testGiaoDichNhaDat {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		DanhSachGiaoDichNhaDat dsGiaoDich = new DanhSachGiaoDichNhaDat();
		try {
			menuGiaoDichNhaDat(dsGiaoDich);
		} catch (Exception e) {
			System.out.println("Lỗi chương trình ! Chương trình đã dừng lại.");
		}
	}

	public static void tieuDe() {
		System.out.println(String.format("%-15s | %15s | %10s | %20s | %-20s | %-15s | %-15s | %25s | %-200s", "Mã Giao Dịch", "Ngày Giao Dịch", "Diện Tích", "Đơn Giá","Loại Giao Dịch" , "Loại Đất","Loại Nhà","Thành Tiền","Địa Chỉ"));
	}

	public static void xuatDanhSachGiaoDich(DanhSachGiaoDichNhaDat dsGiaoDich) {
		System.out.println("\t\t\t\tDANH SÁCH GIAO DỊCH NHÀ ĐẤT");
		tieuDe();
		for(GiaoDich giaoDich: dsGiaoDich.layDanhSachGiaoDich()) {
			System.out.println(giaoDich);
		}
		System.out.println("\n");
	}

	public static void xuatDanhSachThang9Nam2013(DanhSachGiaoDichNhaDat dsGiaoDich) {
		System.out.println("\t\t\t\tDANH SÁCH GIAO DỊCH THÁNG 9 NĂM 2013");
		tieuDe();
		for(GiaoDich giaoDich: dsGiaoDich.giaoDichThang9nam2013()) {
			System.out.println(giaoDich);
		}
		System.out.println("\n");
	}

	public static void tieuDeMenuGiaoDichNhaDat() {
		System.out.println("0. Thêm cứng Giao Dịch.");
		System.out.println("1. Thêm một Giao Dịch.");
		System.out.println("2. Xuất danh sách Giao Dịch.");
		System.out.println("3. Xuất danh sách tháng 9 năm 2013.");
		System.out.println("4. Thoát.");
	}

	public static void menuGiaoDichNhaDat(DanhSachGiaoDichNhaDat dsGiaoDich) {
		int chon = 0;
		do {
			tieuDeMenuGiaoDichNhaDat();
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 4) {
				System.out.println("Chọn sai!! Chọn từ số(1 đến 4)\nChọn lại: ");
			}else {
				switch (chon) {
				case 0:
					nhapCungGiaoDichNhaDat(dsGiaoDich);
					break;
				case 1:
					menuNhapMem(dsGiaoDich);
					break;
				case 2:
					xuatDanhSachGiaoDich(dsGiaoDich);
					break;
				case 3:
					xuatDanhSachThang9Nam2013(dsGiaoDich);
					break;
				default:
					break;
				}
			}
		}while(chon != 4);
	}
	
	public static void tieuDeChonNhapGiaoDichNhaDat() {

		System.out.println("1. Giao Dịch Nhà.");
		System.out.println("2. Giao Dịch Đất.");

	}

	public static void menuNhapMem(DanhSachGiaoDichNhaDat dsGiaoDich) {
		int chon = 0;
		do {
			tieuDeChonNhapGiaoDichNhaDat();
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			if(chon < 0 || chon > 2) {
				System.out.println("Chọn sai!! Chọn từ số(1 đến 2)\nChọn lại: ");
			}else {
				switch (chon) {
				case 1:
					int giaoDichNha = 1;
					nhapMemGiaoDich(dsGiaoDich, giaoDichNha);
					chon = 4132;
					break;
				case 2:
					int giaoDichDat = 2;
					nhapMemGiaoDich(dsGiaoDich, giaoDichDat);
					chon = 4132;
					break;
			
				default:
					break;
				}
			}
		}while(chon != 4132);
	}

	public static void nhapMemGiaoDich(DanhSachGiaoDichNhaDat dsGiaoDich, int loaiGiaoDich) {
		sc.nextLine();
		int giaoDichNha = 1,giaoDichDat = 2;
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Nhập mã giao dịch: ");
		String checkMaGiaoDich = null;
		String maGiaoDich = nhapChuoi(checkMaGiaoDich, "mã giao dịch");

		System.out.println("Nhập đơn giá: ");
		long checkDonGia = 0;
		double donGia = (double) nhapSo(checkDonGia, "đơn giá");

		System.out.println("Nhập diện tích: ");
		long checkDienTich = 0;
		double dienTich = (double) nhapSo(checkDienTich, "diện tích");
		sc.nextLine();
		GregorianCalendar ngayGiaoDich = new GregorianCalendar();
		System.out.println("Nhập ngày Giao Dịch ('dd/mm/yyyy'): ");
		String checktxtNgayGiaoDich = null;
		String textNgayGiaoDich = nhapChuoi(checktxtNgayGiaoDich, "ngày giao dịch");
		try {
			ngayGiaoDich.setTime(fd.parse(textNgayGiaoDich));
		} catch (ParseException e) {
			e.printStackTrace();
			System.out.println("SomeThing wrong!!");throw null;
		}

		if(loaiGiaoDich == giaoDichNha) {
			System.out.println("Chọn loại nhà: ");
			int loaiNha = chonLoaiGiaoDichNha();
		
			sc.nextLine();
			System.out.println("Nhập địa chỉ: ");
			String checkDiaChi = null;
			String diaChi = nhapChuoi(checkDiaChi, "địa chỉ");
			GiaoDich giaoDichMoi = new GiaoDichNha(maGiaoDich, ngayGiaoDich, donGia, dienTich, loaiNha, diaChi);
			dsGiaoDich.themMoiGiaoDich(giaoDichMoi);
		}else if (loaiGiaoDich == giaoDichDat) {
			System.out.println("Chọn loại đất: ");
			String loaiDat = chonLoaiGiaoDichDat();
			GiaoDich giaoDichMoi = new GiaoDichDat(maGiaoDich, ngayGiaoDich, donGia, dienTich, loaiDat);
			dsGiaoDich.themMoiGiaoDich(giaoDichMoi);
		}
		System.out.println("Thêm mới giao dịch: "+maGiaoDich+" - Thành công!");

	}

	public static int chonLoaiGiaoDichNha() {
		int chon = 0,loaiNha = 0;
		do {
			System.out.println("1. Cao Cấp.");
			System.out.println("2. Thường.");
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			if(chon > 2 || chon < 0) {
				System.out.println("Chọn sai! Chọn lại từ (1 đến 2):");
			}else {
				switch (chon) {
				case 1:
					loaiNha = 1;
					chon = 4123;
					break;
				case 2:
					loaiNha = 0;
					chon = 4123;
					break;
				default:
					break;
				}
			}
		}while(chon != 4123);
		return loaiNha;
	}
	
	public static String chonLoaiGiaoDichDat() {
		int chon = 0;
		String loaiDat = null;
		do {
			System.out.println("1. Loại A.");
			System.out.println("2. Loại B.");
			System.out.println("3. Loại C.");
			System.out.println("Bạn chọn số?: ");
			chon = sc.nextInt();
			if(chon > 3 || chon < 0) {
				System.out.println("Chọn sai! Chọn lại từ (1 đến 3):");
			}else {
				switch (chon) {
				case 1:
					loaiDat = "A";
					chon = 4123;
					break;
				case 2:
					loaiDat = "B";
					chon = 4123;
					break;
				case 3:
					loaiDat = "C";
					chon = 4123;
					break;
				default:
					break;
				}
			}
		}while(chon != 4123);
		return loaiDat;
	}
	
	public static void nhapCungGiaoDichNhaDat(DanhSachGiaoDichNhaDat dsGiaoDich) {
		GregorianCalendar ngayNhapVao1 = new GregorianCalendar(2013,9 -1,21);
		GregorianCalendar ngayNhapVao2 = new GregorianCalendar(2019,10 -1,11);
		GiaoDich giaoDich1 = new GiaoDichDat("mã 1", ngayNhapVao1, 1000000, 100, "A");
		GiaoDich giaoDich2 = new GiaoDichDat("mã 2", ngayNhapVao1, 1000000, 110, "B");
		GiaoDich giaoDich3 = new GiaoDichDat("mã 3", ngayNhapVao1, 1000000, 120, "C");

		GiaoDich giaoDich4 = new GiaoDichNha("mã 4", ngayNhapVao2, 2000000, 200, 1, "123 Nguyễn Oanh, Gò Vấp, TPHCM");
		GiaoDich giaoDich5 = new GiaoDichNha("mã 5", ngayNhapVao2, 2100000, 200, 0, "123 Nguyễn Văn Bảo, Gò Vấp, TPHCM");
		dsGiaoDich.themMoiGiaoDich(giaoDich1);
		dsGiaoDich.themMoiGiaoDich(giaoDich2);
		dsGiaoDich.themMoiGiaoDich(giaoDich3);
		dsGiaoDich.themMoiGiaoDich(giaoDich4);
		dsGiaoDich.themMoiGiaoDich(giaoDich5);
		xuatDanhSachGiaoDich(dsGiaoDich);
	}

	//input
	public static long nhapSo(long number, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				number = sc.nextLong();
			} catch (Exception e) {
				System.out.println(title+ "bạn vừa nhập không phải số");
				throw null;
			}
			if(number < 0) {
				System.out.println(title+" - Không được bé hơn 0!\nNhập lại:");
			}
		}while(number < 0);
		return number;
	}

	public static String nhapChuoi(String str, String text) {
		String title = text.substring(0,1).toUpperCase() + text.substring(1).toLowerCase();//in hoa chữ cái đầu
		do {
			try {
				str = sc.nextLine();
			} catch (Exception e) {
				System.out.println("Something wrong!!");
				throw null;
			}
			if(str == null || str.isEmpty()) {
				System.out.println(title+" - Không được để trống!\nNhập lại:");
			}
		}while(str == null || str.isEmpty());
		return str;
	}
	//end input
}
