package tuan4_M4_GiaoDichNhaDat;

import java.util.ArrayList;
import java.util.List;


public class DanhSachGiaoDichNhaDat {
	List<GiaoDich> dsGiaoDich = null;
	public DanhSachGiaoDichNhaDat() {
		dsGiaoDich = new ArrayList<GiaoDich>();
	}
	public boolean themMoiGiaoDich(GiaoDich giaoDich) {
		if(dsGiaoDich.contains(giaoDich)) {
			return false;
		}else {
			dsGiaoDich.add(giaoDich);
			return true;
		}
	}
	
	public int tongSoLuongGDNha() {
		int tong = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichNha) {
				tong++;
			}
		}
		return tong;
	}

	public int tongSoLuongGDDat() {
		int tong = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichDat) {
				tong++;
			}
		}
		return tong;
	}
	
	public double trungBinhThanhTienGiaoDichDat() {
		double trungBinhCong = 0;
		double soRecord = 0;
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich instanceof GiaoDichDat) {
				trungBinhCong = trungBinhCong + giaoDich.tinhThanhTien();
				soRecord++;
			}
		}
		return trungBinhCong/soRecord;
	}
	

	@SuppressWarnings("deprecation")
	public List<GiaoDich> giaoDichThang9nam2013(){
		List<GiaoDich> dsGiaoDichTam = new ArrayList<GiaoDich>();
		for(GiaoDich giaoDich : dsGiaoDich) {
			if(giaoDich.getNgayGiaoDich().getTime().getMonth() + 1 == 9 && giaoDich.getNgayGiaoDich().getTime().getYear() + 1900 == 2013) {
				dsGiaoDichTam.add(giaoDich);
			}
		}
		return dsGiaoDichTam;
	}
	public List<GiaoDich> layDanhSachGiaoDich() {
		return dsGiaoDich;
	}
}
