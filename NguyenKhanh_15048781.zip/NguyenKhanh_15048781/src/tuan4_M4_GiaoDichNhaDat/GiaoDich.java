package tuan4_M4_GiaoDichNhaDat;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public abstract class GiaoDich {
	protected String maGiaoDich;
	protected GregorianCalendar ngayGiaoDich;
	protected double donGia,dienTich;
	protected abstract double tinhThanhTien();
	public String getMaGiaoDich() {
		return maGiaoDich;
	}
	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}
	public GregorianCalendar getNgayGiaoDich() {
		return ngayGiaoDich;
	}
	public void setNgayGiaoDich(GregorianCalendar ngayGiaoDich) {
		this.ngayGiaoDich = ngayGiaoDich;
	}
	public double getDonGia() {
		return donGia;
	}
	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}
	public double getDienTich() {
		return dienTich;
	}
	public void setDienTich(double dienTich) {
		this.dienTich = dienTich;
	}
	/**
	 * @param maGiaoDich
	 * @param ngayGiaoDich
	 * @param donGia
	 * @param dienTich
	 */
	public GiaoDich(String maGiaoDich, GregorianCalendar ngayGiaoDich, double donGia, double dienTich) {
		super();
		this.maGiaoDich = maGiaoDich;
		this.ngayGiaoDich = ngayGiaoDich;
		this.donGia = donGia;
		this.dienTich = dienTich;
	}
	/**
	 * 
	 */
	public GiaoDich() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maGiaoDich == null) ? 0 : maGiaoDich.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GiaoDich other = (GiaoDich) obj;
		if (maGiaoDich == null) {
			if (other.maGiaoDich != null)
				return false;
		} else if (!maGiaoDich.equals(other.maGiaoDich))
			return false;
		return true;
	}
	@Override
	public String toString() {
		SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
		DecimalFormat fm = new DecimalFormat("###,000");
		return String.format("%-15s | %15s | %10.0f | %20s", this.getMaGiaoDich(), fd.format(this.getNgayGiaoDich().getTime()), this.getDienTich(), fm.format(this.getDonGia()));
	}
	
}
